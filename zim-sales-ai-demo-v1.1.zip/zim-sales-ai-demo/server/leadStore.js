import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const dataDir = path.resolve(process.cwd(), 'data');
const filePath = path.join(dataDir, 'leads.json');

function readAll() {
  try {
    if (!fs.existsSync(filePath)) return [];
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

// Lưu lead khi khách để lại SĐT/Zalo trong chat. Cùng user + cùng số thì cập nhật, không tạo trùng.
export function saveLead({ userId = 'anonymous', phone, profile = {} }) {
  if (!phone) return null;
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  const records = readAll();
  const { concerns = [], program, purpose, targetLevel, currentLevel, deadline, schedule, studyMode, painPoint } = profile;
  const needs = { program, purpose, targetLevel, currentLevel, deadline, schedule, studyMode, painPoint, concerns };
  const existing = records.find((r) => r.userId === userId && r.phone === phone);
  const now = new Date().toISOString();
  if (existing) Object.assign(existing, { needs, updatedAt: now });
  else records.push({ id: crypto.randomUUID(), userId, phone, needs, source: 'chatbot', status: 'new', createdAt: now, updatedAt: now });
  const tmp = `${filePath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(records, null, 2), 'utf8');
  fs.renameSync(tmp, filePath);
  return existing || records[records.length - 1];
}

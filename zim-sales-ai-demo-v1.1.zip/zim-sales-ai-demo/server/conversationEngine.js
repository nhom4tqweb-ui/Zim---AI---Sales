// =====================================================================
// CONVERSATION ENGINE – state machine + slot filling + xử lý rào cản
// Mọi dữ kiện về ZIM lấy từ ./zimKnowledge.js (không viết số liệu ở đây).
// Mỗi lượt trả về `parts`: mỗi phần tử là 1 bong bóng chat.
// =====================================================================
import { buildRecommendation } from './recommendationEngine.js';
import { fact, HOTLINE } from './zimKnowledge.js';

/* ---------------------------- Quick replies ---------------------------- */
const QR = {
  initial: [
    ['Tư vấn khóa IELTS', 'program:IELTS'],
    ['Tư vấn khóa TOEIC', 'program:TOEIC'],
    ['Tiếng Anh giao tiếp', 'program:GIAO_TIEP'],
    ['Học phí bao nhiêu?', 'intent:PRICING'],
    ['Làm bài test trình độ', 'intent:PLACEMENT'],
    ['Mình mất gốc, nên bắt đầu từ đâu?', 'intent:LOST_BASE'],
  ],
  programs: [
    ['IELTS', 'program:IELTS'],
    ['TOEIC', 'program:TOEIC'],
    ['Tiếng Anh giao tiếp', 'program:GIAO_TIEP'],
    ['Mình chưa chắc', 'program:UNSURE'],
  ],
  ieltsPurpose: [
    ['Tốt nghiệp', 'purpose:Tốt nghiệp'],
    ['Du học', 'purpose:Du học'],
    ['Công việc', 'purpose:Công việc'],
    ['Định cư', 'purpose:Định cư'],
    ['Mục tiêu khác', 'purpose:Mục tiêu khác'],
  ],
  toeicPurpose: [
    ['Tốt nghiệp', 'purpose:Tốt nghiệp'],
    ['Xin việc', 'purpose:Xin việc'],
    ['Công việc', 'purpose:Công việc'],
    ['Mục tiêu khác', 'purpose:Mục tiêu khác'],
  ],
  communicationPurpose: [
    ['Giao tiếp công việc', 'purpose:Giao tiếp công việc'],
    ['Phỏng vấn', 'purpose:Phỏng vấn'],
    ['Du lịch / đời sống', 'purpose:Du lịch / đời sống'],
    ['Tăng phản xạ', 'purpose:Tăng phản xạ'],
  ],
  ieltsTarget: [
    ['5.5', 'target:5.5'], ['6.0', 'target:6.0'], ['6.5', 'target:6.5'], ['7.0+', 'target:7.0+'], ['Mình chưa rõ', 'target:Chưa rõ'],
  ],
  toeicTarget: [
    ['450', 'target:450'], ['550', 'target:550'], ['650', 'target:650'], ['750+', 'target:750+'], ['Mình chưa rõ', 'target:Chưa rõ'],
  ],
  communicationTarget: [
    ['Giao tiếp cơ bản', 'target:Giao tiếp cơ bản'],
    ['Giao tiếp công việc', 'target:Giao tiếp công việc'],
    ['Phỏng vấn / thuyết trình', 'target:Phỏng vấn / thuyết trình'],
    ['Mình chưa rõ', 'target:Chưa rõ'],
  ],
  ieltsCurrent: [
    ['Chưa từng test', 'current:Chưa từng test'], ['Dưới 4.0', 'current:Dưới 4.0'], ['4.0–4.5', 'current:4.0–4.5'], ['5.0–5.5', 'current:5.0–5.5'], ['6.0+', 'current:6.0+'],
  ],
  toeicCurrent: [
    ['Chưa từng test', 'current:Chưa từng test'], ['Dưới 350', 'current:Dưới 350'], ['350–500', 'current:350–500'], ['500–650', 'current:500–650'], ['650+', 'current:650+'],
  ],
  communicationCurrent: [
    ['Mất gốc / rất ít dùng', 'current:Mất gốc'], ['Biết cơ bản', 'current:Biết cơ bản'], ['Giao tiếp đơn giản', 'current:Giao tiếp đơn giản'], ['Khá nhưng thiếu tự tin', 'current:Khá nhưng thiếu tự tin'],
  ],
  deadline: [
    ['Dưới 2 tháng', 'deadline:Dưới 2 tháng'], ['2–4 tháng', 'deadline:2–4 tháng'], ['4–6 tháng', 'deadline:4–6 tháng'], ['Trên 6 tháng', 'deadline:Trên 6 tháng'], ['Chưa có deadline', 'deadline:Chưa có deadline'],
  ],
  schedule: [
    ['Buổi tối', 'schedule:Buổi tối'], ['Cuối tuần', 'schedule:Cuối tuần'], ['Lịch thay đổi liên tục', 'schedule:Lịch thay đổi liên tục'], ['Mình khá linh hoạt', 'schedule:Linh hoạt'],
  ],
  mode: [
    ['Online', 'mode:Online'], ['Học tại trung tâm', 'mode:Học tại trung tâm'], ['1 kèm 1', 'mode:1 kèm 1'], ['ZIM gợi ý giúp mình', 'mode:Chưa rõ'],
  ],
  pain: [
    ['Mất gốc', 'pain:Mất gốc'], ['Không có thời gian', 'pain:Không có thời gian'], ['Writing/Speaking yếu', 'pain:Writing/Speaking yếu'],
    ['Từng học nhưng chưa tiến bộ', 'pain:Từng học nhưng chưa tiến bộ'], ['Lo về học phí', 'pain:Học phí'], ['Khác', 'pain:Khác'],
  ],
  communicationPain: [
    ['Mất gốc', 'pain:Mất gốc'], ['Không có thời gian', 'pain:Không có thời gian'], ['Ngại nói, thiếu phản xạ', 'pain:Ngại nói, thiếu phản xạ'],
    ['Phát âm chưa chuẩn', 'pain:Phát âm chưa chuẩn'], ['Lo về học phí', 'pain:Học phí'], ['Khác', 'pain:Khác'],
  ],
  ready: [
    ['Làm bài test trình độ', 'next:placement'], ['Hỏi học phí', 'next:pricing'], ['Cam kết đầu ra', 'next:commit'], ['Lịch khai giảng', 'next:schedule'], ['Gặp tư vấn viên', 'next:advisor'],
  ],
  contact: [['Gọi hotline ' + HOTLINE, 'call:hotline'], ['Tiếp tục tư vấn với AI', 'next:continue']],
  continueOnly: [['Tiếp tục tư vấn', 'next:continue']],
};
const replies = (items) => items.map(([label, value]) => ({ label, value }));

/* ------------------------------ Helpers ------------------------------ */
const SLOTS = ['program', 'purpose', 'targetLevel', 'currentLevel', 'deadline', 'schedule', 'studyMode', 'painPoint'];

function norm(text = '') {
  return String(text).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/\s+/g, ' ').trim();
}
const has = (n, list) => list.some((kw) => n.includes(kw));
const lower1 = (s = '') => s.charAt(0).toLowerCase() + s.slice(1);

function isQuestion(n, raw) {
  return raw.includes('?') || /\b(khong|ko|k|chua|nao|sao|gi|bao nhieu|the nao|nhu the nao|duoc khong)\s*$/.test(n) || /^(co|lam sao|bao gio|khi nao|o dau)\b/.test(n);
}

function programLabel(p) { return p === 'Giao tiếp' ? 'Tiếng Anh giao tiếp' : p; }

/* ------------------------ Trích xuất số liệu ------------------------ */
function validBand(v) { const x = Number(v); return x >= 1 && x <= 9 && Math.round(x * 2) === x * 2; }
function validToeic(v) { const x = Number(v); return Number.isInteger(x) && x >= 10 && x <= 990; }
function validFor(program, v) { return program === 'TOEIC' ? validToeic(v) : validBand(v); }
function fmtBand(v) { const x = Number(v); return Number.isInteger(x) ? `${x}.0` : String(x); }

// Bỏ các số đi kèm đơn vị (1 khóa, 4 tháng, 3 triệu, tháng 3...) để không hiểu nhầm thành band/điểm.
function stripUnitNumbers(n) {
  return n
    .replace(/(?:thang|lop|nam)\s*\d+/g, ' ')
    .replace(/\d+(?:[.,]\d+)?\s*(?:thang|tuan|buoi|khoa|trieu|tr\b|k\b|nghin|ngan|dong|d\b|vnd|nguoi|hoc vien|ban\b|nam|tuoi|gio|h\b|lan|phut|ngay|%|cau|bai)/g, ' ');
}

function extractLevels(n, profile, stage) {
  const program = profile.program || 'IELTS';
  const t = stripUnitNumbers(n).replace(/(\d),(\d)/g, '$1.$2');
  const num = '(\\d{1,3}(?:\\.\\d)?)';
  const found = {};

  const pair = t.match(new RegExp(`(?:dang|hien tai|hien|moi duoc|dang o|duoc)\\s*(?:o|la|khoang|tam)?\\s*(?:band|ielts|toeic)?\\s*${num}[^\\d]{0,40}?(?:can|muc tieu|muon|len|dat|den|target)\\s*(?:band|ielts|toeic)?\\s*${num}`));
  if (pair) { found.current = pair[1]; found.target = pair[2]; }
  if (!found.target) {
    const m = t.match(new RegExp(`(?:muc tieu|muon|can|len|dat|target|nham)\\s*(?:duoc|toi|den|khoang|tam)?\\s*(?:band|ielts|toeic)?\\s*${num}`));
    if (m) found.target = m[1];
  }
  if (!found.current) {
    const m = t.match(new RegExp(`(?:hien tai|dang o|dang|band hien tai|moi duoc|thi duoc|lan truoc)\\s*(?:la|khoang|tam|duoc)?\\s*(?:band|ielts|toeic)?\\s*${num}`));
    if (m) found.current = m[1];
  }
  // Câu trả lời ngắn chỉ gồm con số ở đúng bước đang hỏi (VD: "6.5", "tầm 5.0 thôi").
  const bare = t.match(/\d{1,3}(?:\.\d)?/g) || [];
  if (bare.length === 1 && t.length <= 30) {
    if (stage === 'TARGET' && !found.target) found.target = bare[0];
    if (stage === 'CURRENT' && !found.current) found.current = bare[0];
  }

  if (found.current && validFor(program, found.current)) profile.currentLevel = program === 'TOEIC' ? found.current : fmtBand(found.current);
  if (found.target && validFor(program, found.target)) profile.targetLevel = program === 'TOEIC' ? found.target : fmtBand(found.target);
}

function extractDeadline(n, stage) {
  let m = n.match(/(?:trong|con|truoc|khoang|tam|mat|sau|chi con|trong vong)\s*(\d{1,2})\s*thang/) || n.match(/(\d{1,2})\s*thang\s*(?:nua|toi)/);
  if (m) return `${m[1]} tháng`;
  m = n.match(/(?:truoc|vao|den|thi|nop ho so)\s*(?:thang)\s*(\d{1,2})\b/);
  if (m && Number(m[1]) >= 1 && Number(m[1]) <= 12) return `Trước tháng ${m[1]}`;
  if (n.includes('cuoi nam')) return 'Cuối năm';
  if (n.includes('nam sau')) return 'Năm sau';
  if (stage === 'DEADLINE') {
    m = n.match(/(\d{1,2})\s*thang/);
    if (m) return `${m[1]} tháng`;
    if (has(n, ['chua co', 'chua biet', 'chua gap', 'khong gap', 'tu tu'])) return 'Chưa có deadline';
  }
  return null;
}

function extractFromFreeText(raw, profile, stage) {
  const n = norm(raw);
  const low = raw.toLowerCase();

  // Chương trình (đổi chương trình thì xóa mục tiêu/trình độ vì thang điểm khác nhau)
  let program = null;
  if (n.includes('ielts') || /\bband\b/.test(n)) program = 'IELTS';
  else if (n.includes('toeic')) program = 'TOEIC';
  else if (n.includes('giao tiep')) program = 'Giao tiếp';
  if (program && profile.program && program !== profile.program) {
    delete profile.targetLevel; delete profile.currentLevel; delete profile.purpose;
    profile.roadmapShown = false;
  }
  if (program) profile.program = program;

  // Mục đích
  if (has(n, ['tot nghiep', 'ra truong', 'chuan dau ra'])) profile.purpose = 'Tốt nghiệp';
  else if (n.includes('du hoc')) profile.purpose = 'Du học';
  else if (n.includes('dinh cu')) profile.purpose = 'Định cư';
  else if (has(n, ['xet tuyen', 'tuyen sinh', 'thi dai hoc', 'mien thi'])) profile.purpose = 'Xét tuyển / tuyển sinh';
  else if (n.includes('phong van')) profile.purpose = 'Phỏng vấn';
  else if (n.includes('xin viec')) profile.purpose = 'Xin việc';
  else if (has(n, ['cong viec', 'thang tien'])) profile.purpose = profile.program === 'Giao tiếp' ? 'Giao tiếp công việc' : 'Công việc';
  else if (n.includes('du lich')) profile.purpose = 'Du lịch / đời sống';
  else if (stage === 'PURPOSE' && has(n, ['khac', 'ca nhan', 'so thich'])) profile.purpose = 'Mục tiêu khác';

  // Hình thức học
  if (has(n, ['online', 'truc tuyen', 'qua mang'])) profile.studyMode = 'Online';
  else if (has(n, ['1 kem 1', '1-1', '1:1', 'mot kem mot', 'hoc rieng'])) profile.studyMode = '1 kèm 1';
  else if (has(n, ['tai trung tam', 'offline', 'den trung tam', 'hoc truc tiep'])) profile.studyMode = 'Học tại trung tâm';

  // Lịch học ("tối" có dấu để không nhầm với "tôi")
  if (low.includes('tối') && !has(n, ['cuoi tuan'])) profile.schedule = 'Buổi tối';
  else if (n.includes('cuoi tuan') && !low.includes('tối')) profile.schedule = 'Cuối tuần';
  else if (low.includes('tối') && n.includes('cuoi tuan')) profile.schedule = 'Buổi tối hoặc cuối tuần';
  else if (has(n, ['buoi sang', 'hoc sang'])) profile.schedule = 'Buổi sáng';
  else if (has(n, ['buoi chieu', 'hoc chieu'])) profile.schedule = 'Buổi chiều';
  else if (has(n, ['lich thay doi', 'that thuong', 'khong co dinh', 'khong on dinh'])) profile.schedule = 'Lịch thay đổi liên tục';
  else if (n.includes('linh hoat') && stage === 'SCHEDULE') profile.schedule = 'Linh hoạt';

  // Điểm nghẽn (không ghi đè điểm nghẽn khách đã chọn trước đó)
  if (!profile.painPoint) {
    if (n.includes('mat goc')) profile.painPoint = 'Mất gốc';
    else if (has(n, ['writing', 'speaking', 'ky nang viet', 'ky nang noi'])) profile.painPoint = 'Writing/Speaking yếu';
    else if (has(n, ['khong tien bo', 'chua tien bo', 'khong len diem', 'mai khong len'])) profile.painPoint = 'Từng học nhưng chưa tiến bộ';
    else if (low.includes('bận') || has(n, ['khong co thoi gian', 'it thoi gian', 'rat ban', 'kha ban', 'qua ban'])) profile.painPoint = 'Không có thời gian';
    else if (stage === 'PAIN' && raw.trim().length >= 3 && raw.trim().length <= 120) profile.painPoint = raw.trim();
  }

  // Trình độ hiện tại dạng chữ
  if (!profile.currentLevel) {
    if (n.includes('mat goc')) profile.currentLevel = 'Mất gốc';
    else if (has(n, ['chua test', 'chua thi', 'chua lam test', 'chua biet trinh do', 'chua tung'])) profile.currentLevel = 'Chưa từng test';
  }
  if (stage === 'TARGET' && !profile.targetLevel && has(n, ['chua ro', 'chua biet', 'khong biet'])) profile.targetLevel = 'Chưa rõ';

  const deadline = extractDeadline(n, stage);
  if (deadline) profile.deadline = deadline;

  extractLevels(n, profile, stage);
  if (!profile.program && profile.targetLevel && validBand(parseFloat(profile.targetLevel))) profile.program = 'IELTS';
}

function applyAction(action, profile) {
  if (!action || !action.includes(':')) return;
  const [kind, ...rest] = action.split(':');
  const value = rest.join(':');
  const map = { purpose: 'purpose', target: 'targetLevel', current: 'currentLevel', deadline: 'deadline', schedule: 'schedule', mode: 'studyMode', pain: 'painPoint' };
  if (kind === 'program') {
    const p = value === 'GIAO_TIEP' ? 'Giao tiếp' : value === 'UNSURE' ? null : value;
    if (p && profile.program && p !== profile.program) { delete profile.targetLevel; delete profile.currentLevel; delete profile.purpose; profile.roadmapShown = false; }
    profile.program = p;
  } else if (map[kind]) profile[map[kind]] = value;
}

/* --------------------------- Số điện thoại --------------------------- */
const PHONE_RE = /(?:\+?84|0)(?:3|5|7|8|9)\d{8}(?!\d)/;
function extractPhone(raw) {
  const digits = String(raw).replace(/[\s.\-()]/g, '');
  const m = digits.match(PHONE_RE);
  if (!m) return null;
  return m[0].replace(/^\+?84/, '0');
}
const prettyPhone = (p) => p.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');

/* ------------------------- Câu hỏi tiếp theo ------------------------- */
function getNextQuestion(profile) {
  const p = profile.program;
  if (!p) return { stage: 'PROGRAM', question: 'Bạn đang quan tâm IELTS, TOEIC hay Tiếng Anh giao tiếp nè?', quickReplies: replies(QR.programs) };
  if (!profile.purpose) {
    return p === 'IELTS'
      ? { stage: 'PURPOSE', question: 'Bạn học IELTS chủ yếu để làm gì?', quickReplies: replies(QR.ieltsPurpose) }
      : p === 'TOEIC'
        ? { stage: 'PURPOSE', question: 'Bạn cần TOEIC chủ yếu cho mục tiêu nào?', quickReplies: replies(QR.toeicPurpose) }
        : { stage: 'PURPOSE', question: 'Bạn muốn cải thiện giao tiếp chủ yếu trong tình huống nào?', quickReplies: replies(QR.communicationPurpose) };
  }
  if (!profile.targetLevel) {
    return p === 'IELTS'
      ? { stage: 'TARGET', question: 'Bạn đang nhắm band IELTS bao nhiêu?', quickReplies: replies(QR.ieltsTarget) }
      : p === 'TOEIC'
        ? { stage: 'TARGET', question: 'Bạn cần TOEIC khoảng bao nhiêu điểm?', quickReplies: replies(QR.toeicTarget) }
        : { stage: 'TARGET', question: 'Bạn muốn đạt mức giao tiếp nào?', quickReplies: replies(QR.communicationTarget) };
  }
  if (!profile.currentLevel) {
    return p === 'IELTS'
      ? { stage: 'CURRENT', question: 'Band gần nhất của bạn khoảng bao nhiêu? Chưa thi lần nào thì chọn “Chưa từng test” nha.', quickReplies: replies(QR.ieltsCurrent) }
      : p === 'TOEIC'
        ? { stage: 'CURRENT', question: 'Điểm TOEIC gần nhất của bạn khoảng bao nhiêu? Chưa thi thì chọn “Chưa từng test” nha.', quickReplies: replies(QR.toeicCurrent) }
        : { stage: 'CURRENT', question: 'Hiện bạn dùng tiếng Anh ở mức nào?', quickReplies: replies(QR.communicationCurrent) };
  }
  if (!profile.deadline) return { stage: 'DEADLINE', question: 'Bạn muốn đạt mục tiêu trong khoảng bao lâu?', quickReplies: replies(QR.deadline) };
  if (!profile.schedule) return { stage: 'SCHEDULE', question: 'Bạn thường rảnh để học vào khung nào?', quickReplies: replies(QR.schedule) };
  if (!profile.studyMode) return { stage: 'MODE', question: 'Bạn thích học online, tại trung tâm hay 1 kèm 1?', quickReplies: replies(QR.mode) };
  if (!profile.painPoint) {
    return { stage: 'PAIN', question: `Điều gì khiến bạn lo nhất khi học ${p === 'Giao tiếp' ? 'giao tiếp' : p}?`, quickReplies: replies(p === 'Giao tiếp' ? QR.communicationPain : QR.pain) };
  }
  return { stage: 'READY', question: null, quickReplies: replies(QR.ready) };
}

/* ---------------------------- Xác nhận lại ---------------------------- */
function deadlinePhrase(d) {
  if (/^\d/.test(d)) return `trong ${d}`;
  if (/^(dưới|trên)/i.test(d)) return `mốc ${lower1(d)}`;
  return lower1(d);
}
function ackOne(slot, profile) {
  const v = profile[slot];
  switch (slot) {
    case 'program': return 'Được chứ 👌 Mình hỏi vài câu ngắn để gợi ý đúng lộ trình nha.';
    case 'purpose': return v === 'Mục tiêu khác' ? 'Oke bạn.' : `Học để ${lower1(v)}, mình nắm rồi 👍`;
    case 'targetLevel': return v === 'Chưa rõ' ? 'Chưa rõ mục tiêu cũng không sao, tư vấn viên sẽ cùng bạn xác định sau nha.' : `Mục tiêu ${profile.program === 'Giao tiếp' ? lower1(v) : v}, mình ghi nhận rồi 👍`;
    case 'currentLevel':
      if (/chưa|mất gốc/i.test(v)) return 'Không sao nè, bài test trình độ sẽ giúp xác định đúng điểm xuất phát.';
      return `Đầu vào khoảng ${v}, oke nè.`;
    case 'deadline': return v === 'Chưa có deadline' ? 'Chưa có mốc cụ thể thì mình ưu tiên nhịp học dễ duy trì nha.' : `Mốc ${lower1(v)}, mình ghi chú rồi.`;
    case 'schedule': return v === 'Linh hoạt' ? 'Lịch linh hoạt thì dễ xếp lớp hơn nè.' : `${v} nha, mình ghi chú lại.`;
    case 'studyMode': return v === 'Chưa rõ' ? 'Oke, mình sẽ gợi ý hình thức phù hợp trong lộ trình nha.' : `Học ${lower1(v)}, oke bạn.`;
    case 'painPoint': return 'Mình hiểu, mình sẽ ưu tiên xử lý đúng điểm này trong lộ trình.';
    default: return '';
  }
}

const PAIN_PHRASE = {
  'Mất gốc': 'đang mất gốc', 'Không có thời gian': 'lịch khá bận', 'Writing/Speaking yếu': 'Writing/Speaking còn yếu',
  'Từng học nhưng chưa tiến bộ': 'từng học nhưng chưa tiến bộ', 'Học phí': 'đang cân nhắc học phí',
};
function ackMany(slots, profile) {
  const bits = [];
  if (slots.includes('currentLevel') && !/chưa|mất gốc/i.test(profile.currentLevel)) bits.push(`đang ${profile.currentLevel}`);
  if (slots.includes('targetLevel') && profile.targetLevel !== 'Chưa rõ') bits.push(`mục tiêu ${profile.targetLevel}`);
  if (slots.includes('purpose')) bits.push(`để ${lower1(profile.purpose)}`);
  if (slots.includes('deadline')) bits.push(deadlinePhrase(profile.deadline));
  const mode = slots.includes('studyMode') && profile.studyMode !== 'Chưa rõ' ? lower1(profile.studyMode) : '';
  const sched = slots.includes('schedule') ? lower1(profile.schedule) : '';
  if (mode && sched) bits.push(`muốn học ${mode} vào ${sched}`);
  else if (mode) bits.push(`muốn học ${mode}`);
  else if (sched) bits.push(`học vào ${sched}`);
  if (slots.includes('painPoint')) bits.push(PAIN_PHRASE[profile.painPoint] || lower1(profile.painPoint));
  if (slots.includes('currentLevel') && /mất gốc/i.test(profile.currentLevel) && !slots.includes('painPoint')) bits.push('đang mất gốc');
  if (!bits.length) return '';
  return `Mình ghi nhận rồi nè: ${bits.join(', ')} 👍`;
}

/* ---------------------------- Lộ trình ---------------------------- */
function roadmapParts(profile) {
  const rec = buildRecommendation(profile);
  const parts = [];
  const bits = [programLabel(profile.program)];
  if (profile.currentLevel && profile.targetLevel && profile.program !== 'Giao tiếp') bits.push(`từ ${profile.currentLevel} lên ${profile.targetLevel}`);
  else if (profile.targetLevel && profile.targetLevel !== 'Chưa rõ') bits.push(`mục tiêu ${lower1(profile.targetLevel)}`);
  if (profile.deadline && profile.deadline !== 'Chưa có deadline') bits.push(deadlinePhrase(profile.deadline));
  if (profile.studyMode && profile.studyMode !== 'Chưa rõ') bits.push(`học ${lower1(profile.studyMode)}`);
  if (profile.schedule) bits.push(lower1(profile.schedule));
  parts.push(`Mình tóm tắt lại nha: ${bits.join(', ')}.`);
  parts.push(fact('personalized'));
  parts.push(rec.requiresPlacementTest
    ? 'Mình để lộ trình sơ bộ ở thẻ bên dưới. Bước tiếp theo nên là làm bài test trình độ để chốt đúng điểm xuất phát nha.'
    : 'Mình để lộ trình sơ bộ ở thẻ bên dưới. Bạn muốn tìm hiểu thêm phần nào nè?');
  return { parts, recommendation: rec };
}

/* --------------------------- Nhận diện ý định --------------------------- */
const ASKING_INTENTS = new Set(['PRICING', 'PROMO', 'TEACHER', 'FORMAT', 'ONLINE_Q', 'SCHEDULE_INFO', 'TIME_ESTIMATE', 'EXAM', 'TRIAL', 'OUTCOME_FEAR', 'PLACEMENT']);

function detectIntent(raw, n) {
  const q = isQuestion(n, raw);
  if (has(n, ['nguoi that', 'tu van vien', 'nhan vien tu van', 'goi lai', 'goi dien', 'zalo', 'hotline', 'so dien thoai', 'sdt', 'lien he', 'gap tu van'])) return 'ADVISOR';
  if (has(n, ['dang ky thi', 'dang ki thi', 'le phi thi', 'phi thi', 'thi thu', 'thi that', 'british council', 'lich thi', 'ngay thi'])) return 'EXAM';
  if (has(n, ['dat qua', 'hoc phi cao', 'hoc phi dat', 'chi phi cao', 'mac qua', 'hoi mac', 'hoi dat', 'khong du tien', 'dat vay', 'dat the', 'dat lam', 'kha dat'])) return 'EXPENSIVE';
  if (has(n, ['uu dai', 'giam gia', 'khuyen mai', 'voucher', 'hoc bong', 'giam hoc phi', 'dang ky nhom'])) return 'PROMO';
  if (has(n, ['hoc phi', 'bao nhieu tien', 'gia bao nhieu', 'chi phi', 'gia khoa', 'bao nhieu 1 khoa', 'tien 1 khoa', 'gia ca'])) return 'PRICING';
  if (has(n, ['cam ket', 'dau ra', 'khong dat', 'ko dat', 'khong len band', 'truot', 'thi rot', 'so hoc xong', 'so khong'])) return 'OUTCOME_FEAR';
  if (n.includes('hoc thu')) return 'TRIAL';
  if (has(n, ['giao vien', 'giang vien', 'thay co', 'nguoi day', 'ai day'])) return 'TEACHER';
  if (/online/.test(n) && (q || has(n, ['hieu qua', 'co tot', 'co on']))) return 'ONLINE_Q';
  if (has(n, ['si so', 'hinh thuc hoc', 'bao nhieu nguoi', 'lop may nguoi', 'hoc nhom', 'lop nho'])) return 'FORMAT';
  if (n.includes('tu hoc')) return 'SELF_STUDY';
  if (has(n, ['khai giang', 'lich hoc', 'co lop', 'lop nao', 'khi nao hoc'])) return 'SCHEDULE_INFO';
  if (has(n, ['test dau vao', 'kiem tra dau vao', 'test trinh do', 'kiem tra trinh do', 'lam bai test', 'mini test', 'lam test'])) return 'PLACEMENT';
  if (has(n, ['mat goc', 'moi bat dau', 'bat dau tu dau'])) return 'LOST_BASE';
  if (has(n, ['bao lau', 'may thang', 'kip khong', 'mat bao lau', 'bao gio thi dat'])) return 'TIME_ESTIMATE';
  if (raw.toLowerCase().includes('bận') || has(n, ['rat ban', 'kha ban', 'qua ban', 'khong co thoi gian', 'it thoi gian', 'so khong theo kip'])) return 'BUSY';
  if (/\b(sat|pte|vstep)\b/.test(n)) return 'OTHER_PROGRAMS';
  if (has(n, ['de sau', 'luc khac', 'khong can', 'tinh sau', 'suy nghi them'])) return 'LATER';
  if (has(n, ['cam on', 'thank'])) return 'THANKS';
  if (/^(xin chao|chao|hi|hello|alo|hey)\b/.test(n) && n.length <= 25) return 'GREET';
  return null;
}

const ACTION_INTENTS = {
  'next:placement': 'PLACEMENT', 'next:pricing': 'PRICING', 'next:schedule': 'SCHEDULE_INFO', 'next:advisor': 'ADVISOR', 'next:commit': 'OUTCOME_FEAR',
};

/* ---------------------------- Xử lý ý định ---------------------------- */
// Trả về { parts, final?, stage?, quickReplies?, clientAction? }
function handleIntent(intent, profile) {
  const p = profile.program;
  const concern = (c) => { profile.concerns = Array.from(new Set([...(profile.concerns || []), c])); };

  switch (intent) {
    case 'PRICING': {
      concern('Học phí');
      if (!p) return { parts: [`Học phí ở ZIM tùy chương trình nè. ${fact('ieltsFee')} ${fact('ieltsOnlineFee')}`, fact('toeicFee'), 'Bạn cho mình biết đang quan tâm khóa nào để mình tư vấn sát hơn nha.'] };
      if (p === 'IELTS') {
        const tail = getNextQuestion(profile).stage === 'READY'
          ? `Mức cụ thể cho lộ trình của bạn thì tư vấn viên sẽ báo chính xác theo lớp đang mở. ${fact('groupDiscount')}`
          : 'Con số chính xác cho bạn phụ thuộc trình độ đầu vào và mục tiêu, nên mình hỏi thêm vài câu để tư vấn sát hơn nha.';
        return { parts: [`${fact('ieltsFee')} ${fact('ieltsOnlineFee')}`, tail] };
      }
      if (p === 'TOEIC') return { parts: [fact('toeicFee'), fact('groupDiscount')] };
      return { parts: ['Học phí khóa Tiếng Anh giao tiếp sẽ được tư vấn viên báo theo trình độ và lộ trình của bạn nha.', fact('groupDiscount')] };
    }
    case 'EXPENSIVE': {
      concern('Học phí');
      return {
        parts: [
          `Mình hiểu mà, học ${p === 'Giao tiếp' ? 'tiếng Anh' : (p || 'tiếng Anh')} đúng là một khoản đầu tư không nhỏ 🥲`,
          p === 'Giao tiếp' ? fact('commitmentAll') : fact('commitment'),
          `${fact('groupDiscount')} ${fact('trial')}`,
        ],
      };
    }
    case 'PROMO':
      return { parts: [`${fact('groupDiscount')} ${fact('scholarship')}`, fact('mockTest'), 'Ưu đãi đang áp dụng ở thời điểm bạn đăng ký thì tư vấn viên sẽ báo chính xác nha.'] };
    case 'OUTCOME_FEAR': {
      concern('Lo không đạt đầu ra');
      const main = p === 'Giao tiếp' ? fact('commitmentAll') : profile.studyMode === 'Online' && p === 'IELTS' ? fact('commitmentOnline') : fact('commitment');
      return { parts: ['Lo không đạt mục tiêu là tâm lý rất bình thường, mình hiểu 😊', main, `${fact('grading')} ${fact('commitmentDetail')}`] };
    }
    case 'TRIAL':
      return { parts: [fact('trial'), `Bạn nhắn giúp mình số điện thoại hoặc Zalo, tư vấn viên sẽ sắp xếp buổi học thử cho bạn nha. Cần gấp thì gọi hotline ${HOTLINE}.`], final: true, stage: 'CONTACT', quickReplies: replies(QR.contact) };
    case 'TEACHER':
      return { parts: [fact('teachers'), fact('materials')] };
    case 'FORMAT':
      return { parts: [fact('classSizes'), fact('onlineGroups'), fact('selfStudyRoom')] };
    case 'ONLINE_Q':
      return { parts: [fact('onlineGroups'), p === 'IELTS' || !p ? fact('commitmentOnline') : fact('commitmentAll')] };
    case 'SELF_STUDY':
      return {
        parts: ['Tự học được là lợi thế lớn á!', `Có điều Writing và Speaking thì tự chấm cho mình khá khó. ${fact('save80')}`, 'Bạn làm bài test trình độ thử nha, biết rõ điểm mạnh, điểm yếu rồi thì tự học hay học cùng ZIM cũng đỡ mất thời gian hơn.'],
        final: true, stage: profile._stage, quickReplies: replies([['Làm bài test trình độ', 'next:placement'], ['Tiếp tục tư vấn', 'next:continue']]),
      };
    case 'SCHEDULE_INFO': {
      const parts = [`${fact('schedulePage')} Tư vấn viên sẽ lọc giúp bạn lớp đúng khung giờ và còn chỗ.`];
      if (!profile.schedule) return { parts: [...parts, 'Bạn thường rảnh để học vào khung nào?'], final: true, stage: 'SCHEDULE', quickReplies: replies(QR.schedule) };
      return { parts: [...parts, 'Bạn muốn để lại số điện thoại hoặc Zalo để nhận lịch phù hợp không?'], final: true, stage: 'CONTACT', quickReplies: replies(QR.contact) };
    }
    case 'BUSY':
      concern('Bận');
      if (!profile.painPoint) profile.painPoint = 'Không có thời gian';
      return { parts: ['Vừa học vừa làm mà ôn thi thì ai cũng sợ đuối, mình hiểu 😅', `${fact('onlineGroups')} ${fact('oneOneBusy')}`, fact('videos')] };
    case 'LOST_BASE': {
      if (!profile.painPoint) profile.painPoint = 'Mất gốc';
      if (!profile.currentLevel) profile.currentLevel = 'Mất gốc';
      if (p === 'Giao tiếp') return { parts: ['Mất gốc cũng đừng lo nha 😊', fact('communication')] };
      if (p === 'TOEIC') return { parts: ['Mất gốc cũng đừng lo nha 😊 Mình sẽ ưu tiên xây lại nền tảng trước khi luyện đề.', fact('personalized')] };
      if (p === 'IELTS') return { parts: ['Mất gốc thì chưa nên vào luyện đề ngay, mình sẽ ưu tiên xây lại nền tảng rồi tăng band theo từng chặng.', fact('allLevels')] };
      return { parts: ['Mất gốc cũng đừng lo nha 😊', `${fact('allLevels')} Còn khóa Giao tiếp thì bắt đầu từ giai đoạn dành cho người mất gốc, luyện phát âm chuẩn theo IPA.`] };
    }
    case 'TIME_ESTIMATE': {
      const ready = getNextQuestion(profile).stage === 'READY';
      return { parts: ['Thời gian đạt mục tiêu phụ thuộc nhiều nhất vào điểm xuất phát và số giờ bạn học mỗi tuần, nên mình không muốn đoán đại một con số.', ready ? `${fact('personalized')} Sau khi có kết quả test, tư vấn viên sẽ ước lượng sát hơn cho bạn.` : fact('personalized')] };
    }
    case 'PLACEMENT':
      return {
        parts: [`Được nè 👍 Mình mở bài kiểm tra trình độ ngay bên dưới cho bạn. ${fact('personalized')}`],
        final: true, stage: profile._stage, clientAction: 'open_placement', quickReplies: replies(QR.continueOnly),
      };
    case 'ADVISOR':
      return {
        parts: ['Được nhé, mình kết nối bạn với tư vấn viên của ZIM.', `Bạn nhắn giúp mình số điện thoại hoặc Zalo nhé, tư vấn viên sẽ liên hệ lại. Cần gấp thì bạn gọi hotline ${HOTLINE} nha.`],
        final: true, stage: 'CONTACT', quickReplies: replies(QR.contact),
      };
    case 'EXAM':
      return {
        parts: [fact('examPartner'), `${fact('examFee')} ${fact('examEarly')}`, `${fact('examPerks')} ${fact('mockTest')}`],
        final: true, stage: profile._stage,
        quickReplies: replies([['Để lại SĐT để đăng ký thi', 'next:advisor'], ['Tiếp tục tư vấn khóa học', 'next:continue']]),
      };
    case 'OTHER_PROGRAMS':
      return { parts: [fact('programs'), `Các chương trình này mình kết nối bạn với tư vấn viên để được tư vấn đúng mục tiêu nhé. Bạn để lại số điện thoại hoặc Zalo, hoặc gọi ${HOTLINE} nha.`], final: true, stage: 'CONTACT', quickReplies: replies(QR.contact) };
    case 'LATER':
      return { parts: [`Oke bạn, không sao nha 😊 Cần gì cứ nhắn mình, hoặc gọi hotline ${HOTLINE}.`], final: true, stage: profile._stage, quickReplies: replies(QR.continueOnly) };
    case 'THANKS':
      return { parts: ['Không có gì nè 😊'] };
    case 'GREET':
      return { parts: ['Chào bạn 😊'] };
    default:
      return null;
  }
}

/* ------------------------------ Respond ------------------------------ */
function continuation(profile, { withQuestionPrefix = '' } = {}) {
  const next = getNextQuestion(profile);
  if (next.stage === 'READY') {
    if (!profile.roadmapShown) {
      const { parts, recommendation } = roadmapParts(profile);
      profile.roadmapShown = true;
      return { stage: 'READY', parts: withQuestionPrefix ? [withQuestionPrefix, ...parts] : parts, quickReplies: next.quickReplies, recommendation };
    }
    return { stage: 'READY', parts: [withQuestionPrefix ? `${withQuestionPrefix} Bạn muốn tìm hiểu thêm phần nào nữa không?` : 'Bạn muốn tìm hiểu thêm phần nào nữa không?'], quickReplies: next.quickReplies };
  }
  return { stage: next.stage, parts: [withQuestionPrefix ? `${withQuestionPrefix} ${next.question}` : next.question], quickReplies: next.quickReplies };
}

function finalize(profile, out) {
  delete profile._stage;
  return { stage: out.stage, profile, parts: out.parts.filter(Boolean), text: out.parts.filter(Boolean).join('\n\n'), quickReplies: out.quickReplies || [], recommendation: out.recommendation || null, intent: out.intent || null, clientAction: out.clientAction || null, leadCaptured: out.leadCaptured || false };
}

export function respond({ message = '', action = '', stage = 'PROGRAM', profile: rawProfile = {} } = {}) {
  const profile = JSON.parse(JSON.stringify(rawProfile || {}));
  profile._stage = stage;
  const raw = String(message || '').slice(0, 500);
  const n = norm(raw);
  const before = Object.fromEntries(SLOTS.map((s) => [s, profile[s]]));

  // 0) Nút gọi hotline (xử lý phía client), chỉ trả lời nhẹ
  if (action === 'call:hotline') {
    return finalize(profile, { stage, parts: [`Bạn gọi ${HOTLINE} để gặp tư vấn viên ZIM nha. Cần hỏi thêm gì cứ nhắn mình.`], quickReplies: replies(QR.continueOnly) });
  }

  // 1) Số điện thoại / Zalo
  const phone = !action ? extractPhone(raw) : null;
  if (phone) {
    profile.phone = phone;
    profile.fallbackCount = 0;
    const cont = continuation(profile);
    const intro = [`Cảm ơn bạn! Mình đã ghi nhận số ${prettyPhone(phone)}.`, `Tư vấn viên của ZIM sẽ liên hệ lại với bạn. Cần gấp thì bạn gọi hotline ${HOTLINE} nha.`];
    const parts = cont.stage === 'READY' && profile.roadmapShown && cont.parts.length === 1
      ? [...intro, 'Trong lúc chờ, bạn có muốn làm bài test trình độ luôn không?']
      : [...intro, 'Trong lúc chờ, mình hỏi thêm vài câu để tư vấn viên nắm trước nhu cầu của bạn nhé.', ...cont.parts];
    return finalize(profile, { ...cont, parts, intent: 'LEAD', leadCaptured: true });
  }
  if (!action && stage === 'CONTACT' && (raw.replace(/\D/g, '').length >= 6)) {
    return finalize(profile, { stage: 'CONTACT', parts: ['Hình như số này chưa đúng lắm, bạn kiểm tra lại giúp mình nha (VD: 0912 345 678).'], quickReplies: replies(QR.contact), intent: 'LEAD_INVALID' });
  }

  // 2) Chưa chắc chọn chương trình
  if (action === 'program:UNSURE') {
    profile.program = null;
    return finalize(profile, { stage: 'PROGRAM', parts: ['Không sao nè 😊 Nếu bạn cần chứng chỉ để tốt nghiệp, du học hay làm hồ sơ công việc thì thường chọn IELTS hoặc TOEIC; còn nếu muốn dùng tiếng Anh hằng ngày thì có thể bắt đầu với giao tiếp.', 'Bạn muốn xem hướng nào trước?'], quickReplies: replies(QR.programs.slice(0, 3)) });
  }

  // 3) Cập nhật dữ liệu
  applyAction(action, profile);
  if (!action) extractFromFreeText(raw, profile, stage);
  const changed = SLOTS.filter((s) => profile[s] !== before[s] && profile[s]);

  // 4) Xác định ý định
  let intent = null;
  if (action.startsWith('intent:')) intent = action.slice(7);
  else if (ACTION_INTENTS[action]) intent = ACTION_INTENTS[action];
  else if (!action) {
    intent = detectIntent(raw, n);
    // Câu mô tả bản thân có nhiều thông tin: chỉ coi là hỏi khi thực sự là câu hỏi
    const infoSlots = changed.filter((s) => s !== 'program');
    if (intent && infoSlots.length >= 2 && !(ASKING_INTENTS.has(intent) && isQuestion(n, raw)) && intent !== 'ADVISOR') intent = null;
  }

  // 5) Tiếp tục tư vấn
  if (action === 'next:continue') {
    profile.fallbackCount = 0;
    const cont = continuation(profile);
    return finalize(profile, { ...cont, parts: [cont.stage === 'READY' ? cont.parts[0] : `Mình tiếp tục nha 😊 ${cont.parts[0]}`, ...cont.parts.slice(1)] });
  }

  if (intent) {
    const handled = handleIntent(intent, profile);
    if (handled) {
      profile.fallbackCount = 0;
      const infoSlots = changed.filter((s) => s !== 'program');
      const ack = infoSlots.length >= 2 ? ackMany(infoSlots, profile) : '';
      const lead = ack ? [ack, ...handled.parts] : handled.parts;
      if (handled.final) return finalize(profile, { stage: handled.stage || stage, parts: lead, quickReplies: handled.quickReplies, intent, clientAction: handled.clientAction });
      const cont = continuation(profile);
      return finalize(profile, { ...cont, parts: [...lead, ...cont.parts], intent });
    }
  }

  // 6) Có thông tin mới → xác nhận ngắn + hỏi tiếp
  if (changed.length) {
    profile.fallbackCount = 0;
    const infoSlots = changed.filter((s) => s !== 'program');
    let ack;
    if (infoSlots.length >= 2) ack = ackMany(infoSlots, profile);
    else if (infoSlots.length === 1) ack = ackOne(infoSlots[0], profile);
    else ack = before.program && before.program !== profile.program ? `Oke, mình chuyển sang tư vấn ${programLabel(profile.program)} nha.` : ackOne('program', profile);
    const cont = continuation(profile);
    if (cont.stage === 'READY' && cont.recommendation) return finalize(profile, { ...cont, parts: [ack, ...cont.parts] });
    return finalize(profile, { ...cont, parts: [`${ack} ${cont.parts[0]}`, ...cont.parts.slice(1)] });
  }

  // 7a) Trả lời số nhưng ngoài thang điểm
  if ((stage === 'TARGET' || stage === 'CURRENT') && /\d/.test(raw) && ['IELTS', 'TOEIC'].includes(profile.program)) {
    const cont = continuation(profile);
    const hint = profile.program === 'TOEIC' ? 'Điểm TOEIC tính từ 10 đến 990 nè.' : 'Band IELTS tính từ 1.0 đến 9.0, theo bước 0.5 nè.';
    return finalize(profile, { ...cont, parts: [`${hint} ${cont.parts[0]}`], intent: 'INVALID_LEVEL' });
  }

  // 7) Không hiểu → dự phòng, không lặp vô hạn
  profile.fallbackCount = (profile.fallbackCount || 0) + 1;
  const help = `Mình chưa hiểu ý bạn lắm 😅 Mình hỗ trợ tư vấn các khóa học ở ZIM: bạn có thể hỏi về học phí, lịch học, cam kết đầu ra, hoặc để lại số điện thoại để tư vấn viên gọi lại nha.`;
  if (profile.fallbackCount >= 2) {
    return finalize(profile, { stage: 'CONTACT', parts: [help, `Nếu tiện, bạn nhắn số điện thoại hoặc Zalo, hoặc gọi hotline ${HOTLINE} để được hỗ trợ trực tiếp nhé.`], quickReplies: replies(QR.contact), intent: 'FALLBACK' });
  }
  const cont = continuation(profile);
  return finalize(profile, { ...cont, parts: [help, ...cont.parts], intent: 'FALLBACK' });
}

export function initialGreeting() {
  const parts = ['Chào bạn 👋 Mình là trợ lý tư vấn AI của Anh Ngữ ZIM.', 'Bạn đang tìm hiểu khóa nào, hay cần mình giải đáp gì nè?'];
  return { stage: 'PROGRAM', profile: {}, parts, text: parts.join('\n\n'), quickReplies: replies(QR.initial) };
}

import fs from 'node:fs';
import path from 'node:path';

function loadDotEnv() {
  const envPath = path.resolve(process.cwd(), '.env');
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
    const idx = trimmed.indexOf('=');
    const key = trimmed.slice(0, idx).trim();
    let value = trimmed.slice(idx + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
}

loadDotEnv();

export const config = {
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || '0.0.0.0',
  llmApiUrl: process.env.LLM_API_URL || '',
  llmApiKey: process.env.LLM_API_KEY || '',
  llmModel: process.env.LLM_MODEL || '',
  enableLlmNaturalization: process.env.ENABLE_LLM_NATURALIZATION === 'true',
  // ZIM chưa công bố mức giảm lệ phí thi cụ thể → mặc định không có giá trị tiền.
  demoVoucherAmount: process.env.DEMO_VOUCHER_AMOUNT ? Number(process.env.DEMO_VOUCHER_AMOUNT) : null,
  demoVoucherDays: Number(process.env.DEMO_VOUCHER_DAYS || 30),
  brandName: 'ZIM',
};
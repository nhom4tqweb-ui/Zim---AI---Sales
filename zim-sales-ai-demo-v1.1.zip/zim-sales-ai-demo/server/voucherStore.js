import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from './config.js';
import { EXAM_REWARD_PERKS } from './zimKnowledge.js';

const dataDir = path.resolve(process.cwd(), 'data');
const filePath = path.join(dataDir, 'vouchers.json');

function ensureStore() {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, '[]', 'utf8');
}

function readAll() {
  ensureStore();
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAll(records) {
  const tempPath = `${filePath}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(records, null, 2), 'utf8');
  fs.renameSync(tempPath, filePath);
}

function createCode() {
  return `ZIM-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

export function claimVoucher({ userId, courseId = 'demo-ielts-course', courseName = 'IELTS Demo Course' } = {}) {
  if (!userId) throw new Error('userId is required');
  const records = readAll();
  const existing = records.find((item) => item.userId === userId && item.courseId === courseId && item.status !== 'cancelled');
  if (existing) return { ...existing, idempotent: true };

  const createdAt = new Date();
  const expiresAt = new Date(createdAt.getTime() + config.demoVoucherDays * 24 * 60 * 60 * 1000);
  const voucher = {
    id: crypto.randomUUID(),
    code: createCode(),
    userId,
    courseId,
    courseName,
    type: 'IELTS_EXAM_OFFER',
    amount: config.demoVoucherAmount, // null = không hiển thị số tiền (ZIM chưa công bố mức giảm)
    perks: EXAM_REWARD_PERKS.map(({ title, value, detail }) => ({ title, value, detail })),
    currency: 'VND',
    status: 'claimed',
    createdAt: createdAt.toISOString(),
    claimedAt: createdAt.toISOString(),
    redeemedAt: null,
    expiresAt: expiresAt.toISOString(),
    note: 'Mã dùng trong bản demo bài tập.',
  };
  records.push(voucher);
  writeAll(records);
  return { ...voucher, idempotent: false };
}
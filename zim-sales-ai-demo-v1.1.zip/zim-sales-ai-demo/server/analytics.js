import fs from 'node:fs';
import path from 'node:path';

const dataDir = path.resolve(process.cwd(), 'data');
const logPath = path.join(dataDir, 'analytics.ndjson');

export function trackEvent(event = {}) {
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  const safe = {
    name: String(event.name || 'unknown').slice(0, 80),
    userId: event.userId ? String(event.userId).slice(0, 120) : null,
    sessionId: event.sessionId ? String(event.sessionId).slice(0, 120) : null,
    properties: event.properties && typeof event.properties === 'object' ? event.properties : {},
    at: new Date().toISOString(),
  };
  fs.appendFileSync(logPath, `${JSON.stringify(safe)}\n`, 'utf8');
  return safe;
}
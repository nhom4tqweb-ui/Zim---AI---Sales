import { config } from './config.js';

function buildSystemPrompt() {
  return [
    'Bạn là ZIM AI Consultant, tư vấn viên học tập trên website trung tâm Anh ngữ ZIM.',
    'Giọng điệu: tự nhiên, thân thiện, gọn, giống một tư vấn viên trẻ chuyên nghiệp; không nói kiểu máy móc hay tài liệu kỹ thuật.',
    'Ưu tiên 2-4 câu ngắn cho mỗi lượt. Mỗi lượt chỉ có một câu hỏi chính.',
    'Phản hồi trực tiếp điều khách vừa quan tâm trước, sau đó mới hỏi dữ liệu còn thiếu.',
    'Không hỏi lại dữ liệu đã biết và không biến cuộc trò chuyện thành bảng khảo sát.',
    'Có thể dùng emoji nhẹ như 👋, 👍, 😊, 👌 nhưng không lạm dụng.',
    'Không gây áp lực mua, không dùng FOMO.',
    'Giữ nguyên tuyệt đối mọi dữ kiện về ZIM có trong câu nền (học phí, cam kết đầu ra, sĩ số, hotline, lệ phí thi, ưu đãi); không thêm, bớt hay sửa con số.',
    'Không tự tạo học phí, lịch khai giảng, ưu đãi, chính sách hay dữ kiện nào không có trong câu nền.',
    'Giữ nguyên các dòng trống ngăn cách giữa các đoạn: mỗi đoạn là một tin nhắn riêng.',
    'Không thay đổi logic nghiệp vụ, câu hỏi tiếp theo hoặc quick reply do hệ thống cung cấp.',
    'Chỉ làm câu trả lời nền tự nhiên hơn; giữ nguyên ý nghĩa, dữ kiện và cảnh báo quan trọng.',
  ].join('\n');
}

// Nhận mảng parts (mỗi phần là 1 bong bóng chat), trả về mảng parts.
export async function maybeNaturalizeParts(parts, context = {}) {
  const joined = parts.join('\n\n');
  const out = await maybeNaturalize(joined, context);
  if (out === joined) return parts;
  const split = out.split(/\n{2,}/).map((x) => x.trim()).filter(Boolean);
  return split.length ? split : parts;
}

export async function maybeNaturalize(baseText, context = {}) {
  if (!config.enableLlmNaturalization || !config.llmApiUrl || !config.llmApiKey || !config.llmModel) {
    return baseText;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(config.llmApiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.llmApiKey}`,
      },
      body: JSON.stringify({
        model: config.llmModel,
        temperature: 0.3,
        messages: [
          { role: 'system', content: buildSystemPrompt() },
          {
            role: 'user',
            content: JSON.stringify({
              task: 'Viết lại câu trả lời nền tự nhiên hơn, ngắn gọn và không thêm thông tin mới.',
              baseText,
              profile: context.profile || {},
              latestUserMessage: context.message || '',
            }),
          },
        ],
      }),
      signal: controller.signal,
    });

    if (!response.ok) return baseText;
    const data = await response.json();
    const text = data?.choices?.[0]?.message?.content?.trim();
    return text || baseText;
  } catch {
    return baseText;
  } finally {
    clearTimeout(timeout);
  }
}

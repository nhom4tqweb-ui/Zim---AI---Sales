// =====================================================================
// RECOMMENDATION ENGINE – business rules sinh lộ trình sơ bộ
// Các "điểm phù hợp" (highlights) chỉ dùng dữ kiện trong zimKnowledge.js.
// Các chặng band là mốc học tập gợi ý, KHÔNG phải tên khóa học của ZIM.
// =====================================================================
import { fact } from './zimKnowledge.js';

const IELTS_MILESTONES = [4.5, 5.5, 6.5, 7.5];

function numbers(text) {
  return String(text || '').replace(/,/g, '.').match(/\d+(?:\.\d+)?/g)?.map(Number) || [];
}

function needsPlacement(current) {
  return !current || /chưa|mất gốc/i.test(String(current));
}

function ieltsRoute(current, target) {
  const t = numbers(target)[0];
  if (!t) return ['Làm bài test trình độ', 'Xác định band mục tiêu cùng tư vấn viên'];
  if (needsPlacement(current)) return ['Làm bài test trình độ', 'Củng cố nền tảng', `Mục tiêu ${target}`];
  const c = Math.max(...numbers(current));
  if (c >= t) return ['Rà soát kỹ năng còn yếu', `Giữ vững ${target}+`, 'Luyện đề theo mục tiêu'];
  const route = [`Hiện tại ${current}`];
  for (const m of IELTS_MILESTONES) if (m > c && m < t) route.push(`Chặng ${m}`);
  route.push(`Mục tiêu ${target}`);
  return route;
}

function monthsOf(deadline) {
  const d = String(deadline || '');
  if (/dưới 2/i.test(d)) return 1;
  const n = numbers(d);
  return n.length ? Math.max(...n) : null;
}

function urgencyNote(deadline) {
  const d = String(deadline || '');
  const m = monthsOf(d);
  if (/chưa có/i.test(d)) return 'Chưa có mốc thi nên ưu tiên một nhịp học đều, dễ duy trì.';
  if (m !== null && m <= 2 && !/trên/i.test(d)) return 'Mốc thời gian khá sát, nên làm test trình độ sớm để xem có cần tăng cường độ học không.';
  return 'Nên chia mục tiêu thành từng chặng ngắn và theo dõi tiến độ sau mỗi giai đoạn.';
}

// Chọn tối đa 2 dữ kiện ZIM phù hợp nhất với hồ sơ khách.
function pickHighlights(profile) {
  const picks = [];
  const add = (key) => { const t = fact(key); if (!picks.includes(t)) picks.push(t); };
  const m = monthsOf(profile.deadline);
  const urgent = m !== null && m <= 2 && !/trên/i.test(profile.deadline || '');

  if (urgent && profile.program !== 'Giao tiếp') { add('intensive'); add('oneOneFast'); }
  if (/thay đổi/i.test(profile.schedule || '')) add('oneOneBusy');
  if (profile.studyMode === 'Online') add('onlineGroups');
  if (profile.studyMode === '1 kèm 1') add('oneOneBusy');
  switch (profile.painPoint) {
    case 'Mất gốc': add(profile.program === 'Giao tiếp' ? 'communication' : 'allLevels'); break;
    case 'Writing/Speaking yếu': add('grading'); break;
    case 'Không có thời gian': add('videos'); break;
    case 'Học phí': add('groupDiscount'); break;
    case 'Từng học nhưng chưa tiến bộ': add(profile.program === 'Giao tiếp' ? 'commitmentAll' : 'commitment'); break;
    default: break;
  }
  if (picks.length < 2) add(profile.program === 'Giao tiếp' ? 'commitmentAll' : 'commitment');
  return picks.slice(0, 2);
}

export function buildRecommendation(profile = {}) {
  const program = profile.program || 'IELTS';
  const common = {
    requiresPlacementTest: needsPlacement(profile.currentLevel),
    preferredMode: profile.studyMode && profile.studyMode !== 'Chưa rõ' ? profile.studyMode : 'Tư vấn viên gợi ý',
    preferredTime: profile.schedule || 'Chưa xác định',
    focus: profile.painPoint || 'Chưa xác định',
    highlights: pickHighlights({ ...profile, program }),
    note: urgencyNote(profile.deadline),
    disclaimer: 'Lộ trình là gợi ý sơ bộ. Học phí, lịch khai giảng và ưu đãi được tư vấn viên xác nhận theo thời điểm đăng ký.',
  };
  const summary = `Xuất phát: ${profile.currentLevel || 'chưa xác định'} · Mục tiêu: ${profile.targetLevel || 'chưa xác định'} · Thời gian: ${profile.deadline || 'chưa xác định'}`;

  if (program === 'IELTS') {
    return { ...common, title: `Lộ trình gợi ý IELTS ${profile.targetLevel && profile.targetLevel !== 'Chưa rõ' ? profile.targetLevel : ''}`.trim(), summary, route: ieltsRoute(profile.currentLevel, profile.targetLevel) };
  }
  if (program === 'TOEIC') {
    const target = profile.targetLevel && profile.targetLevel !== 'Chưa rõ' ? `Mục tiêu ${profile.targetLevel}` : 'Mục tiêu TOEIC';
    return {
      ...common, title: 'Lộ trình gợi ý TOEIC', summary,
      route: common.requiresPlacementTest ? ['Làm bài test trình độ', 'Củng cố nền tảng', target] : [`Hiện tại ${profile.currentLevel}`, 'Tập trung phần còn yếu', target],
    };
  }
  return {
    ...common,
    title: 'Lộ trình gợi ý Tiếng Anh giao tiếp',
    summary: `Mục tiêu: ${profile.targetLevel || profile.purpose || 'giao tiếp'} · Hiện tại: ${profile.currentLevel || 'chưa xác định'} · Lịch: ${profile.schedule || 'chưa xác định'}`,
    route: ['Đánh giá đầu vào', 'Củng cố phát âm và nền tảng', 'Thực hành theo tình huống mục tiêu'],
  };
}

// =====================================================================
// KHO THÔNG TIN ZIM (nguồn duy nhất cho mọi dữ kiện chatbot được nói)
// ---------------------------------------------------------------------
// Quy tắc:
// - Chỉ thêm dữ kiện có trên website/kênh chính thức của ZIM, kèm link nguồn.
// - Không tự thêm con số, ưu đãi, lịch khai giảng hay điều kiện cam kết.
// - Học phí/ưu đãi có thể thay đổi: kiểm tra lại các link trước buổi bảo vệ.
// Lần đối chiếu gần nhất: 22/09/2026.
// =====================================================================

export const SOURCES = {
  home: 'https://zim.vn/',
  ielts: 'https://zim.vn/ielts',
  ieltsOnline: 'https://zim.vn/ielts/ielts-online',
  ielts1on1: 'https://zim.vn/ielts/cap-toc-1-kem-1',
  feeIelts: 'https://zim.vn/hoc-phi-ielts',
  examRegistration: 'https://zim.vn/ielts/dang-ky-thi-ielts-tai-anh-ngu-zim',
  youtube: 'https://www.youtube.com/@zimacademy',
};

export const HOTLINE = '1900 2833';

export const FACTS = {
  // ----- Định vị & phương pháp -----
  programs: {
    text: 'Ngoài IELTS, TOEIC và Tiếng Anh Giao Tiếp, ZIM còn có luyện thi SAT, PTE và VSTEP.',
    src: SOURCES.home,
  },
  personalized: {
    text: 'Ở ZIM, lộ trình được cá nhân hóa dựa trên bài kiểm tra đầu vào và mục tiêu điểm của học viên.',
    src: SOURCES.feeIelts,
  },
  save80: {
    text: 'Phương pháp học cá nhân hóa của ZIM giúp học viên rút ngắn 80% thời gian tự học.',
    src: SOURCES.home,
  },
  allLevels: {
    text: 'Lộ trình IELTS ở ZIM có thiết kế cho mọi trình độ, kể cả người mới bắt đầu hay mất gốc tiếng Anh.',
    src: SOURCES.ieltsOnline,
  },
  communication: {
    text: 'Khóa Tiếng Anh Giao Tiếp ở ZIM gồm 5 giai đoạn, đi từ mất gốc đến giao tiếp tự nhiên. Giai đoạn đầu luyện phát âm chuẩn theo phiên âm IPA và xây nền từ vựng, ngữ pháp căn bản.',
    src: SOURCES.home,
  },

  // ----- Cam kết đầu ra -----
  commitment: {
    text: 'ZIM cam kết chất lượng khóa học theo kết quả bài thi: nếu học viên không đạt điểm cam kết thì được tài trợ học lại và miễn phí thi lại.',
    src: SOURCES.youtube,
  },
  commitmentOnline: {
    text: 'Với khóa IELTS Online, nếu chưa đạt kết quả như cam kết, ZIM sẽ phân tích lại nguyên nhân và tài trợ chi phí học lại, ôn thi lại cho học viên.',
    src: SOURCES.ieltsOnline,
  },
  commitmentAll: {
    text: 'Các khóa ở ZIM, gồm luyện thi IELTS, TOEIC, SAT, PTE, VSTEP và Tiếng Anh Giao Tiếp, đều có cam kết đầu ra.',
    src: SOURCES.home,
  },
  commitmentDetail: {
    text: 'Chi tiết cam kết cho khóa của bạn sẽ được tư vấn viên giải thích rõ khi đăng ký.',
    src: null, // câu điều hướng, không phải dữ kiện
  },

  // ----- Học phí & ưu đãi -----
  ieltsFee: {
    text: 'Học phí IELTS tại ZIM từ 3.900.000đ/khóa, tùy lộ trình và các yếu tố như thời lượng, cường độ học.',
    src: SOURCES.ielts,
  },
  ieltsOnlineFee: {
    text: 'Riêng các khóa IELTS Online thì từ 7.900.000đ/khóa.',
    src: SOURCES.ieltsOnline,
  },
  toeicFee: {
    text: 'Học phí TOEIC tại ZIM từ 900.000đ/tháng, tùy lộ trình, thời lượng và cường độ học.',
    src: SOURCES.home,
  },
  groupDiscount: {
    text: 'ZIM có ưu đãi học phí khi đăng ký theo nhóm.',
    src: SOURCES.ielts,
  },
  scholarship: {
    text: 'Học viên đạt giải quốc gia, quốc tế được cấp học bổng từ bán phần đến toàn phần.',
    src: SOURCES.home,
  },
  trial: {
    text: 'ZIM luôn khuyến khích học viên học thử trước khi đăng ký chính thức, để xem môi trường học có phù hợp không.',
    src: SOURCES.ieltsOnline,
  },

  // ----- Giáo viên & học liệu -----
  teachers: {
    text: 'Đội ngũ giảng dạy IELTS ở ZIM có trình độ IELTS từ 7.5 đến 8.5.',
    src: SOURCES.feeIelts,
  },
  materials: {
    text: 'Giáo trình, tài liệu do đội ngũ giáo viên ZIM biên soạn riêng cho kỳ thi IELTS và cập nhật theo xu hướng đề thi mới.',
    src: SOURCES.ielts,
  },
  grading: {
    text: 'Bài thực hành được giáo viên chấm chữa, có khóa còn có thêm hệ thống chấm bài ZIM Correct.',
    src: SOURCES.home,
  },
  videos: {
    text: 'ZIM có hệ thống video bài học bổ trợ để bạn ôn lại kiến thức khi cần.',
    src: SOURCES.ielts1on1,
  },
  selfStudyRoom: {
    text: 'Ngoài giờ học trên lớp, các trung tâm của ZIM đều có phòng tự học có giảng viên hướng dẫn.',
    src: SOURCES.ielts1on1,
  },

  // ----- Hình thức & sĩ số -----
  classSizes: {
    text: 'Về sĩ số, ZIM có lớp 1 kèm 1, lớp Micro 8 học viên và lớp Standard 15 học viên.',
    src: SOURCES.home,
  },
  onlineGroups: {
    text: 'Học online ở ZIM thì học ở đâu cũng được, miễn có kết nối internet, với lớp nhóm nhỏ 1–3, 5 hoặc 10 học viên.',
    src: SOURCES.ieltsOnline,
  },
  intensive: {
    text: 'ZIM có lớp cấp tốc học trên 3 buổi/tuần, thay vì 2–3 buổi/tuần như khóa tiêu chuẩn.',
    src: SOURCES.ieltsOnline,
  },
  oneOneBusy: {
    text: 'Học 1 kèm 1 phù hợp với học viên bận rộn, không có thời gian cố định và muốn linh động lịch học theo nhu cầu.',
    src: SOURCES.ielts1on1,
  },
  oneOneFast: {
    text: 'Học 1 kèm 1 cũng được thiết kế cho học viên cần đạt điểm cao trong thời gian ngắn.',
    src: SOURCES.ielts1on1,
  },
  schedulePage: {
    text: 'ZIM cập nhật lịch khai giảng các khóa theo từng tháng trên website zim.vn.',
    src: SOURCES.home,
  },

  // ----- Thi IELTS -----
  examPartner: {
    text: 'Anh Ngữ ZIM là đối tác đăng ký thi hạng cao nhất của British Council tại Việt Nam, nên đăng ký thi qua ZIM thủ tục nhanh và đơn giản.',
    src: SOURCES.ielts,
  },
  examFee: {
    text: 'Lệ phí thi IELTS khi đăng ký qua ZIM là 4.664.000đ.',
    src: SOURCES.examRegistration,
  },
  examEarly: {
    text: 'Mỗi đợt thi có giới hạn số thí sinh, nên bạn nên đăng ký trước ngày thi khoảng 2 tháng để giữ chỗ.',
    src: SOURCES.examRegistration,
  },
  examPerks: {
    text: 'Khi đăng ký thi IELTS qua ZIM, bạn có thêm những ưu đãi kèm theo.',
    src: SOURCES.examRegistration,
  },
  mockTest: {
    text: 'ZIM tặng 200.000đ khi đăng ký thi thử IELTS, nhận kết quả trong ngày.',
    src: SOURCES.examRegistration,
  },
};

export const fact = (key) => FACTS[key].text;

// Quyền lợi hiển thị trong modal voucher (chỉ dùng dữ kiện có nguồn).
export const EXAM_REWARD_PERKS = [
  { title: 'Đăng ký thi IELTS qua ZIM', value: 'Ưu đãi kèm theo khi đăng ký', detail: `${fact('examFee')} ZIM là đối tác đăng ký thi hạng cao nhất của British Council tại Việt Nam.`, src: SOURCES.examRegistration },
  { title: 'Thi thử IELTS tại ZIM', value: 'Tặng 200.000đ', detail: 'Khi đăng ký thi thử IELTS tại ZIM, nhận kết quả trong ngày.', src: SOURCES.examRegistration },
];

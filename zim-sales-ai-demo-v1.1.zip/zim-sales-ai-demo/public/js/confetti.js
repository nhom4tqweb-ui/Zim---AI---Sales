export function runConfetti({ duration = 1400, particles = 90 } = {}) {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const canvas = document.createElement('canvas');
  canvas.id = 'confetti-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d', { alpha: true });
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  function resize() {
    canvas.width = Math.floor(innerWidth * dpr);
    canvas.height = Math.floor(innerHeight * dpr);
    canvas.style.width = `${innerWidth}px`;
    canvas.style.height = `${innerHeight}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();

  const palette = ['#B91C1C', '#4F46E5', '#059669', '#F59E0B', '#E11D48'];
  const items = Array.from({ length: particles }, () => ({
    x: innerWidth * (0.2 + Math.random() * 0.6),
    y: innerHeight * 0.18 + Math.random() * 18,
    vx: (Math.random() - 0.5) * 8,
    vy: -4 - Math.random() * 6,
    gravity: 0.18 + Math.random() * 0.08,
    rotation: Math.random() * Math.PI,
    rotationSpeed: (Math.random() - 0.5) * 0.22,
    width: 5 + Math.random() * 7,
    height: 3 + Math.random() * 6,
    color: palette[Math.floor(Math.random() * palette.length)],
    ticket: false,
  }));
  // Thêm vài "phiếu voucher" mini bay cùng pháo giấy
  for (let i = 0; i < 12; i += 1) {
    items.push({
      x: innerWidth * (0.3 + Math.random() * 0.4), y: innerHeight * 0.2, vx: (Math.random() - 0.5) * 6, vy: -5 - Math.random() * 5,
      gravity: 0.15 + Math.random() * 0.05, rotation: (Math.random() - 0.5) * 0.8, rotationSpeed: (Math.random() - 0.5) * 0.08,
      width: 26, height: 15, color: i % 2 ? '#B91C1C' : '#059669', ticket: true,
    });
  }

  const start = performance.now();
  let rafId = 0;

  function frame(now) {
    const elapsed = now - start;
    ctx.clearRect(0, 0, innerWidth, innerHeight);

    for (const p of items) {
      p.vy += p.gravity;
      p.x += p.vx;
      p.y += p.vy;
      p.rotation += p.rotationSpeed;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rotation);
      ctx.fillStyle = p.color;
      ctx.fillRect(-p.width / 2, -p.height / 2, p.width, p.height);
      if (p.ticket) {
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath(); ctx.arc(-p.width / 2, 0, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(p.width / 2, 0, 3, 0, Math.PI * 2); ctx.fill();
        ctx.fillRect(-p.width / 2 + 7, -p.height / 2 + 3, 1.5, p.height - 6);
      }
      ctx.restore();
    }

    if (elapsed < duration) rafId = requestAnimationFrame(frame);
    else cleanup();
  }

  function cleanup() {
    cancelAnimationFrame(rafId);
    window.removeEventListener('resize', resize);
    canvas.remove();
  }

  window.addEventListener('resize', resize, { passive: true });
  rafId = requestAnimationFrame(frame);
  setTimeout(cleanup, duration + 250);
}
// =====================================================================
// ZIM AI Consultant – widget chat nổi góc phải
// - Mỗi lượt bot có thể gồm nhiều bong bóng (server gửi sự kiện "break").
// - Stream được gom theo requestAnimationFrame, không render từng token.
// - Tin nhắn gửi khi bot đang trả lời sẽ được xếp hàng, không làm đơ giao diện.
// =====================================================================
const STORAGE_KEY = 'zim-chat-state-v4';
const MAX_MESSAGES = 80;
const HOTLINE_TEL = 'tel:19002833';

function el(tag, className = '', text = '') {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
    if (parsed && Array.isArray(parsed.messages)) return parsed;
  } catch {}
  return null;
}

function saveState(state) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...state, messages: state.messages.slice(-MAX_MESSAGES) })); } catch {}
}

function isNearBottom(container) {
  return container.scrollHeight - container.scrollTop - container.clientHeight < 96;
}

function scrollToBottom(container, force = false) {
  if (!force && !isNearBottom(container)) return;
  const smooth = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  requestAnimationFrame(() => container.scrollTo({ top: container.scrollHeight, behavior: smooth ? 'smooth' : 'auto' }));
}

function parseSseBlock(block) {
  const line = block.split('\n').find((item) => item.startsWith('data:'));
  if (!line) return null;
  try { return JSON.parse(line.slice(5).trim()); } catch { return null; }
}

function createAvatar() {
  return el('div', 'mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-indigo-600 text-xs font-bold text-white', 'AI');
}

function createAssistantBubble(text = '', { showMeta = true } = {}) {
  const row = el('div', 'zim-message flex items-start gap-2.5');
  const wrap = el('div', 'max-w-[84%]');
  const bubble = el('div', 'whitespace-pre-line rounded-2xl rounded-tl-md border border-slate-200 bg-white px-3.5 py-2.5 text-sm leading-relaxed text-slate-700 shadow-sm');
  const textNode = document.createTextNode(text);
  bubble.appendChild(textNode);
  wrap.appendChild(bubble);
  if (showMeta) wrap.appendChild(el('div', 'mt-1 px-1 text-[11px] text-slate-400', 'ZIM AI Consultant'));
  const avatar = createAvatar();
  if (!showMeta) avatar.classList.add('invisible');
  row.append(avatar, wrap);
  return { row, textNode };
}

function createUserBubble(text) {
  const row = el('div', 'zim-message flex justify-end');
  const wrap = el('div', 'max-w-[84%]');
  wrap.append(
    el('div', 'rounded-2xl rounded-tr-md bg-slate-800 px-3.5 py-2.5 text-sm leading-relaxed text-white', text),
    el('div', 'mt-1 px-1 text-right text-[11px] text-slate-400', 'Bạn'),
  );
  row.appendChild(wrap);
  return row;
}

function createTyping() {
  const row = el('div', 'flex items-start gap-2.5');
  const bubble = el('div', 'flex items-center gap-1 rounded-2xl rounded-tl-md border border-slate-200 bg-white px-4 py-3 shadow-sm');
  bubble.setAttribute('aria-label', 'ZIM AI đang nhập');
  bubble.append(el('span', 'zim-typing-dot'), el('span', 'zim-typing-dot'), el('span', 'zim-typing-dot'));
  row.append(createAvatar(), bubble);
  return row;
}

function createRecommendationCard(rec) {
  const card = el('div', 'zim-message ml-9 mr-2 rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4');
  card.append(
    el('div', 'text-[11px] font-semibold text-indigo-700', 'Lộ trình gợi ý'),
    el('h4', 'mt-1 text-sm font-bold text-slate-800', rec.title || 'Lộ trình đề xuất'),
    el('p', 'mt-1.5 text-xs leading-relaxed text-slate-600', rec.summary || ''),
  );
  const route = el('ol', 'mt-3 flex flex-wrap items-center gap-1.5');
  (rec.route || []).forEach((item, i) => {
    if (i > 0) route.appendChild(el('li', 'text-xs text-indigo-300', '›'));
    route.appendChild(el('li', 'rounded-full border border-indigo-200 bg-white px-2.5 py-1 text-xs font-semibold text-indigo-700', item));
  });
  card.appendChild(route);
  if (rec.highlights?.length) {
    const list = el('ul', 'mt-3 space-y-1.5');
    for (const h of rec.highlights) {
      const li = el('li', 'flex gap-2 text-xs leading-relaxed text-slate-600');
      li.append(el('span', 'font-bold text-emerald-600', '✓'), el('span', '', h));
      list.appendChild(li);
    }
    card.appendChild(list);
  }
  if (rec.note) card.appendChild(el('p', 'mt-3 text-xs leading-relaxed text-slate-500', rec.note));
  if (rec.disclaimer) card.appendChild(el('p', 'mt-3 border-t border-indigo-100 pt-3 text-[11px] leading-relaxed text-slate-500', rec.disclaimer));
  return card;
}

export async function mountChat({ root, userId, track }) {
  let state = loadState() || { stage: 'PROGRAM', profile: {}, quickReplies: [], messages: [], draft: '' };
  let isOpen = false;
  let isStreaming = false;
  let isUserTyping = false;
  let typingTimer = null;
  let controller = null;
  const pendingQueue = [];
  let rafPending = false;
  let streamBuffer = '';
  let activeTextNode = null;
  let activeMessageText = '';

  /* ------------------------------ Khung giao diện ------------------------------ */
  const shell = el('div', 'fixed bottom-5 right-4 z-50 md:right-6');
  const preview = el('button', 'focus-ring absolute bottom-[74px] right-0 w-64 rounded-2xl border border-slate-200 bg-white p-3 text-left text-sm text-slate-700 shadow-lg transition hover:-translate-y-0.5');
  preview.type = 'button';
  const previewTitle = el('span', 'block text-[11px] font-semibold text-indigo-600', 'ZIM AI Consultant');
  const previewText = el('span', 'mt-1 block leading-relaxed', 'Bạn cần IELTS bao nhiêu và thi khi nào? Nhắn mình tư vấn lộ trình nha 👋');
  preview.append(previewTitle, previewText);

  const launcher = el('button', 'chat-launcher-pulse focus-ring relative ml-auto grid h-14 w-14 place-items-center rounded-full bg-indigo-600 text-white shadow-xl transition hover:bg-indigo-700');
  launcher.type = 'button';
  launcher.setAttribute('aria-label', 'Mở khung chat tư vấn ZIM');
  launcher.innerHTML = `
    <svg viewBox="0 0 24 24" width="27" height="27" fill="none" aria-hidden="true">
      <path d="M5.25 4.75h13.5A2.25 2.25 0 0 1 21 7v8.25a2.25 2.25 0 0 1-2.25 2.25H10l-4.9 3.15a.75.75 0 0 1-1.15-.63V17.1A2.25 2.25 0 0 1 3 15.25V7a2.25 2.25 0 0 1 2.25-2.25Z" fill="currentColor"/>
      <circle cx="8" cy="11" r="1.15" fill="#4F46E5"/><circle cx="12" cy="11" r="1.15" fill="#4F46E5"/><circle cx="16" cy="11" r="1.15" fill="#4F46E5"/>
    </svg>`;
  const unreadDot = el('span', 'absolute -top-1 -left-1 hidden h-5 min-w-[20px] place-items-center rounded-full bg-red-700 px-1 text-[11px] font-semibold text-white');
  launcher.appendChild(unreadDot);

  const panel = el('section', 'zim-chat-panel absolute bottom-0 right-0 hidden flex-col overflow-hidden rounded-2xl border border-slate-200 bg-slate-50 shadow-2xl');
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', 'Chat tư vấn ZIM AI Consultant');

  const header = el('header', 'flex items-center justify-between gap-2 border-b border-slate-200 bg-white px-4 py-3');
  const headerLeft = el('div', 'flex min-w-0 items-center gap-3');
  const logo = el('div', 'grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-indigo-600 text-sm font-bold text-white', 'AI');
  const titleWrap = el('div', 'min-w-0');
  const badge = el('span', 'inline-flex items-center gap-1.5 rounded-full border border-indigo-200 bg-indigo-50 px-2.5 py-0.5 text-[11px] font-semibold text-indigo-700', '✦ ZIM AI Consultant');
  const status = el('div', 'mt-1 flex items-center gap-1.5 text-[11px] text-slate-500');
  status.append(el('span', 'h-1.5 w-1.5 rounded-full bg-emerald-500'), document.createTextNode('Trợ lý AI của Anh Ngữ ZIM'));
  titleWrap.append(badge, status);
  headerLeft.append(logo, titleWrap);
  const headerActions = el('div', 'flex shrink-0 items-center gap-1');
  const humanBtn = el('button', 'focus-ring whitespace-nowrap rounded-full border border-slate-200 px-2.5 py-1.5 text-[11px] font-semibold text-red-700 hover:border-red-200 hover:bg-red-50', 'Gặp tư vấn viên');
  humanBtn.type = 'button';
  const resetBtn = el('button', 'focus-ring rounded-lg p-2 text-xs text-slate-400 hover:bg-slate-100 hover:text-slate-700', '↻');
  resetBtn.type = 'button';
  resetBtn.title = 'Bắt đầu lại cuộc tư vấn';
  resetBtn.setAttribute('aria-label', 'Bắt đầu lại cuộc tư vấn');
  const closeBtn = el('button', 'focus-ring rounded-lg p-2 text-sm text-slate-400 hover:bg-slate-100 hover:text-slate-700', '✕');
  closeBtn.type = 'button';
  closeBtn.setAttribute('aria-label', 'Đóng khung chat');
  headerActions.append(humanBtn, resetBtn, closeBtn);
  header.append(headerLeft, headerActions);

  const messageArea = el('div', 'zim-chat-scroll flex-1 overflow-y-auto px-3 py-4');
  messageArea.setAttribute('role', 'log');
  messageArea.setAttribute('aria-live', 'polite');
  const messageStack = el('div', 'space-y-2');
  const quickHost = el('div', 'mt-3 flex flex-wrap gap-2 pl-9');
  const queueStatus = el('div', 'mt-2 hidden pl-9 text-[11px] text-slate-400', 'Tin nhắn của bạn sẽ được gửi ngay sau câu trả lời này…');
  messageArea.append(messageStack, quickHost, queueStatus);

  const footer = el('footer', 'border-t border-slate-200 bg-white p-3');
  const composer = el('div', 'flex items-end gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-sm focus-within:border-indigo-300 focus-within:ring-2 focus-within:ring-indigo-100');
  const input = el('textarea', 'max-h-28 min-h-[40px] flex-1 resize-none bg-transparent px-2 py-2 text-sm text-slate-700 outline-none placeholder:text-slate-400');
  input.rows = 1;
  input.maxLength = 500;
  input.placeholder = 'Nhập tin nhắn…';
  input.setAttribute('aria-label', 'Nhập tin nhắn cho ZIM AI');
  input.value = state.draft || '';
  const sendBtn = el('button', 'focus-ring grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-red-700 text-white transition hover:bg-red-800', '➤');
  sendBtn.type = 'button';
  sendBtn.setAttribute('aria-label', 'Gửi tin nhắn');
  composer.append(input, sendBtn);
  footer.append(composer, el('p', 'mt-2 px-1 text-[10px] leading-snug text-slate-400', 'Bạn đang trò chuyện với trợ lý AI. Học phí, lịch khai giảng và ưu đãi được tư vấn viên ZIM xác nhận theo thời điểm đăng ký.'));

  panel.append(header, messageArea, footer);
  shell.append(preview, launcher, panel);
  root.replaceChildren(shell);

  /* ------------------------------ Trạng thái ------------------------------ */
  const dispatchBusy = () => window.dispatchEvent(new CustomEvent('zim:chat-busy', { detail: { busy: isStreaming || isUserTyping } }));
  const setStreaming = (v) => { isStreaming = v; dispatchBusy(); };
  const setTyping = (v) => { isUserTyping = v; dispatchBusy(); };
  const persist = () => { state.draft = input.value; saveState(state); };

  let unread = 0;
  function bumpUnread() {
    if (isOpen) return;
    unread += 1;
    unreadDot.textContent = String(unread);
    unreadDot.classList.remove('hidden');
    unreadDot.classList.add('grid');
  }

  function appendStoredMessage(message, prev) {
    if (message.role === 'user') return messageStack.appendChild(createUserBubble(message.text));
    if (message.role === 'card') return messageStack.appendChild(createRecommendationCard(message.data));
    // Gom các bong bóng liên tiếp của bot: chỉ bong bóng cuối hiện nhãn
    const node = createAssistantBubble(message.text, { showMeta: true }).row;
    if (prev && prev.role === 'assistant') {
      const lastRow = messageStack.lastElementChild;
      lastRow?.querySelector('.text-\\[11px\\]')?.remove();
      lastRow?.firstElementChild?.classList.add('invisible');
    }
    messageStack.appendChild(node);
  }

  function renderQuickReplies() {
    quickHost.replaceChildren();
    if (!state.quickReplies?.length || isStreaming) return;
    const first = state.messages.filter((m) => m.role === 'user').length === 0;
    if (first) quickHost.appendChild(el('div', 'w-full pb-1 text-[11px] font-medium text-slate-400', 'Bạn có thể chọn nhanh:'));
    for (const item of state.quickReplies) {
      const button = el('button', first
        ? 'focus-ring w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-left text-xs font-semibold text-slate-700 shadow-sm transition hover:border-indigo-200 hover:bg-indigo-50/40 hover:text-indigo-700'
        : 'focus-ring rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 shadow-sm transition hover:border-indigo-200 hover:text-indigo-700', item.label);
      button.type = 'button';
      button.addEventListener('click', () => {
        if (item.value === 'call:hotline') window.location.href = HOTLINE_TEL;
        sendMessage(item.label, item.value);
      });
      quickHost.appendChild(button);
    }
  }

  function renderAll() {
    messageStack.replaceChildren();
    state.messages.forEach((m, i) => appendStoredMessage(m, state.messages[i - 1]));
    renderQuickReplies();
    scrollToBottom(messageArea, true);
  }

  async function bootstrap() {
    if (state.messages.length) { renderAll(); return; }
    let initial;
    try {
      initial = await (await fetch('/api/chat/initial', { cache: 'no-store' })).json();
    } catch {
      initial = { stage: 'PROGRAM', profile: {}, parts: ['Chào bạn 👋 Mình là trợ lý tư vấn AI của Anh Ngữ ZIM.', 'Kết nối đang chậm một chút, bạn thử nhắn lại sau giây lát nha. Cần gấp thì gọi hotline 1900 2833.'], quickReplies: [] };
    }
    state.stage = initial.stage;
    state.profile = initial.profile || {};
    state.quickReplies = initial.quickReplies || [];
    for (const text of initial.parts || [initial.text]) state.messages.push({ role: 'assistant', text, at: Date.now() });
    persist();
    renderAll();
  }

  /* ------------------------------ Streaming ------------------------------ */
  function flushStreamBuffer() {
    rafPending = false;
    if (!activeTextNode || !streamBuffer) return;
    activeMessageText += streamBuffer;
    streamBuffer = '';
    activeTextNode.nodeValue = activeMessageText;
    scrollToBottom(messageArea, false);
  }

  function queueDelta(text) {
    streamBuffer += text;
    if (!rafPending) { rafPending = true; requestAnimationFrame(flushStreamBuffer); }
  }

  async function processSend(message, action = '') {
    const clean = String(message || '').trim();
    if (!clean && !action) return;

    setTyping(false);
    input.value = '';
    persist();
    state.quickReplies = [];
    renderQuickReplies();

    const userMessage = clean || 'Tiếp tục';
    state.messages.push({ role: 'user', text: userMessage, at: Date.now() });
    messageStack.appendChild(createUserBubble(userMessage));
    scrollToBottom(messageArea, true);
    persist();
    track('conversation_message_sent', { stage: state.stage, action: action || null });

    let typingNode = createTyping();
    messageStack.appendChild(typingNode);
    scrollToBottom(messageArea, true);
    setStreaming(true);
    controller = new AbortController();
    let meta = null;
    let lastBubbleRow = null;

    const finishBubble = () => {
      flushStreamBuffer();
      if (activeTextNode && activeMessageText) {
        state.messages.push({ role: 'assistant', text: activeMessageText, at: Date.now() });
        bumpUnread();
      }
      activeTextNode = null;
      activeMessageText = '';
      streamBuffer = '';
    };

    try {
      const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({ message: userMessage, action, stage: state.stage, profile: state.profile, userId }),
      });
      if (!response.ok || !response.body) throw new Error('chat request failed');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const blocks = buffer.split('\n\n');
        buffer = blocks.pop() || '';
        for (const block of blocks) {
          const event = parseSseBlock(block);
          if (!event) continue;
          if (event.type === 'meta') {
            meta = event;
            state.stage = event.stage;
            state.profile = event.profile || state.profile;
            if (event.intent && !['LEAD', 'LEAD_INVALID', 'FALLBACK'].includes(event.intent)) track('objection_detected', { intent: event.intent, stage: state.stage });
            if (event.intent === 'ADVISOR') track('human_handoff_requested', { stage: state.stage });
          }
          if (event.type === 'delta') {
            if (!activeTextNode) {
              typingNode?.remove();
              typingNode = null;
              if (lastBubbleRow) { // bong bóng trước không cần nhãn nữa
                lastBubbleRow.querySelector('.text-\\[11px\\]')?.remove();
                lastBubbleRow.firstElementChild?.classList.add('invisible');
              }
              const bubble = createAssistantBubble('');
              lastBubbleRow = bubble.row;
              activeTextNode = bubble.textNode;
              messageStack.appendChild(bubble.row);
            }
            queueDelta(event.text || '');
          }
          if (event.type === 'break') {
            finishBubble();
            typingNode = createTyping();
            messageStack.appendChild(typingNode);
            scrollToBottom(messageArea, false);
          }
          if (event.type === 'done') finishBubble();
        }
      }
      finishBubble();
      typingNode?.remove();

      if (meta?.recommendation) {
        state.messages.push({ role: 'card', data: meta.recommendation, at: Date.now() });
        messageStack.appendChild(createRecommendationCard(meta.recommendation));
        track('roadmap_generated', { program: state.profile.program, target: state.profile.targetLevel });
      }
      state.quickReplies = meta?.quickReplies || [];
      if (meta?.clientAction === 'open_placement') {
        track('placement_test_clicked', { program: state.profile.program || null });
        window.dispatchEvent(new CustomEvent('zim:open-step', { detail: { step: 2, profile: { ...state.profile } } }));
      }
      if (meta?.intent === 'PRICING') track('pricing_requested', { program: state.profile.program || null });
      persist();
    } catch (error) {
      typingNode?.remove();
      finishBubble();
      const messageText = error.name === 'AbortError'
        ? 'Mình đã dừng câu trả lời trước. Thông tin bạn nhập vẫn được giữ nguyên nha.'
        : 'Kết nối đang chậm một chút. Thông tin bạn nhập vẫn còn, bạn thử gửi lại giúp mình nha.';
      state.messages.push({ role: 'assistant', text: messageText, at: Date.now() });
      messageStack.appendChild(createAssistantBubble(messageText).row);
      persist();
    } finally {
      controller = null;
      setStreaming(false);
      renderQuickReplies();
      scrollToBottom(messageArea, true);
      if (pendingQueue.length) {
        queueStatus.classList.add('hidden');
        const next = pendingQueue.shift();
        setTimeout(() => processSend(next.message, next.action), 30);
      }
    }
  }

  function sendMessage(message, action = '') {
    if (isStreaming) {
      pendingQueue.push({ message, action });
      queueStatus.classList.remove('hidden');
      return;
    }
    processSend(message, action);
  }

  /* ------------------------------ API ra ngoài ------------------------------ */
  function open() {
    isOpen = true;
    unread = 0;
    unreadDot.classList.add('hidden');
    unreadDot.classList.remove('grid');
    panel.classList.remove('hidden');
    panel.classList.add('flex');
    launcher.classList.add('hidden');
    preview.classList.add('hidden');
    if (window.matchMedia('(min-width: 641px)').matches) input.focus({ preventScroll: true });
    scrollToBottom(messageArea, true);
    track('chat_opened', { stage: state.stage });
  }

  function close() {
    isOpen = false;
    panel.classList.add('hidden');
    panel.classList.remove('flex');
    launcher.classList.remove('hidden');
    persist();
  }

  // Mở chat và gửi sẵn một câu (dùng cho CTA ở các module khác).
  function ask(message, action = '') {
    open();
    sendMessage(message, action);
  }

  // Bot chủ động nhắn (không gọi server), VD sau khi đóng modal chúc mừng.
  function notify(parts = [], quickReplies = []) {
    if (isStreaming) return;
    parts.forEach((text, i) => {
      state.messages.push({ role: 'assistant', text, at: Date.now() });
      appendStoredMessage({ role: 'assistant', text }, i === 0 ? state.messages[state.messages.length - 2] : { role: 'assistant' });
      bumpUnread();
    });
    if (quickReplies.length) state.quickReplies = quickReplies;
    renderQuickReplies();
    persist();
    if (!isOpen) {
      previewText.textContent = parts[0] || '';
      preview.classList.remove('hidden');
      setTimeout(() => { if (!isOpen) preview.classList.add('hidden'); }, 8000);
    }
    scrollToBottom(messageArea, true);
  }

  async function reset() {
    controller?.abort();
    pendingQueue.length = 0;
    localStorage.removeItem(STORAGE_KEY);
    state = { stage: 'PROGRAM', profile: {}, quickReplies: [], messages: [], draft: '' };
    input.value = '';
    quickHost.replaceChildren();
    messageStack.replaceChildren();
    await bootstrap();
    track('chat_reset');
  }

  launcher.addEventListener('click', open);
  preview.addEventListener('click', open);
  closeBtn.addEventListener('click', close);
  resetBtn.addEventListener('click', reset);
  humanBtn.addEventListener('click', () => sendMessage('Mình muốn gặp tư vấn viên', 'next:advisor'));
  sendBtn.addEventListener('click', () => sendMessage(input.value));
  input.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      sendMessage(input.value);
    }
  });
  input.addEventListener('input', () => {
    persist();
    setTyping(Boolean(input.value.trim()));
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => setTyping(false), 900);
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && isOpen && document.getElementById('completion-modal')?.getAttribute('aria-hidden') !== 'false') close();
  });

  setTimeout(() => { if (!isOpen) preview.classList.add('hidden'); }, 8000);

  await bootstrap();
  track('chat_widget_viewed');

  return { open, close, reset, ask, notify, isOpen: () => isOpen, getState: () => structuredClone(state) };
}

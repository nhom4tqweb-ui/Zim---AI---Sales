const USER_KEY = 'zim-demo-user-id';

function getUserId() {
  let id = null;
  try { id = localStorage.getItem(USER_KEY); } catch {}
  if (!id) {
    id = crypto.randomUUID ? crypto.randomUUID() : `user-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    try { localStorage.setItem(USER_KEY, id); } catch {}
  }
  return id;
}

const userId = getUserId();
const sessionId = crypto.randomUUID ? crypto.randomUUID() : `session-${Date.now()}`;
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let chatApiPromise = null;
let chatBusy = false;
let queuedCompletion = null;
let previouslyFocused = null;

export function track(name, properties = {}) {
  const body = JSON.stringify({ name, userId, sessionId, properties });
  if (navigator.sendBeacon) {
    const blob = new Blob([body], { type: 'application/json' });
    if (navigator.sendBeacon('/api/events', blob)) return;
  }
  fetch('/api/events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => {});
}

function toast(message) {
  const node = document.getElementById('toast');
  if (!node) return;
  node.textContent = message;
  node.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add('hidden'), 2200);
}

/* ------------------------------ Chatbot (lazy-load) ------------------------------ */
async function ensureChat() {
  if (!chatApiPromise) {
    chatApiPromise = import('./chat.js').then((module) => module.mountChat({ root: document.getElementById('chat-root'), userId, sessionId, track }));
  }
  return chatApiPromise;
}

function loadChatWhenIdle() {
  const load = () => ensureChat().catch(() => {});
  if ('requestIdleCallback' in window) window.requestIdleCallback(load, { timeout: 1600 });
  else setTimeout(load, 500);
}

for (const id of ['open-chat-header', 'open-chat-hero', 'open-chat-card']) {
  document.getElementById(id)?.addEventListener('click', async () => (await ensureChat()).open());
}

// Khi chatbot yêu cầu làm test: cuộn tới khối Mini Test (Step 2 của nhóm gắn vào đây).
window.addEventListener('zim:open-step', async (event) => {
  if (event.detail?.step !== 2) return;
  const box = document.getElementById('assessment-box');
  if (!box) return;
  if (window.matchMedia('(max-width: 640px)').matches) (await ensureChat()).close();
  box.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
  box.classList.add('ring-4', 'ring-indigo-200');
  setTimeout(() => box.classList.remove('ring-4', 'ring-indigo-200'), 1800);
});
document.getElementById('start-placement')?.addEventListener('click', () => {
  window.dispatchEvent(new CustomEvent('zim:open-step', { detail: { step: 2, profile: {} } }));
  toast('Phần Mini Test sẽ được ghép từ Step 2 của nhóm.');
});

window.addEventListener('zim:chat-busy', (event) => {
  chatBusy = Boolean(event.detail?.busy);
  if (!chatBusy && queuedCompletion) {
    const detail = queuedCompletion;
    queuedCompletion = null;
    requestAnimationFrame(() => showCompletionModal(detail));
  }
});

/* ------------------------------ Modal chúc mừng + voucher ------------------------------ */
const modal = document.getElementById('completion-modal');
const claimButton = document.getElementById('claim-voucher');
const closeButton = document.getElementById('close-completion');
const deferButton = document.getElementById('defer-voucher');
const voucherResult = document.getElementById('voucher-result');
const voucherCode = document.getElementById('voucher-code');
const voucherMeta = document.getElementById('voucher-meta');
const voucherError = document.getElementById('voucher-error');
const perkList = document.getElementById('perk-list');
const courseNameLabel = document.getElementById('completion-course-name');
let claimed = false;
let perksLoaded = false;

async function loadPerks() {
  if (perksLoaded) return;
  try {
    const { perks } = await (await fetch('/api/rewards/exam', { cache: 'no-store' })).json();
    perkList.replaceChildren(...perks.map((perk, i) => {
      const card = document.createElement('div');
      card.className = `voucher-card ticket-in rounded-2xl border-2 border-dashed ${i === 0 ? 'border-red-200' : 'border-emerald-200'} px-5 py-4`;
      card.style.animationDelay = reduceMotion ? '0ms' : `${450 + i * 160}ms`;
      card.innerHTML = `
        <p class="text-xs font-semibold ${i === 0 ? 'text-red-700' : 'text-emerald-700'}"></p>
        <p class="mt-0.5 text-lg font-extrabold ${i === 0 ? 'text-red-700' : 'text-emerald-700'}"></p>
        <p class="mt-1 text-xs leading-relaxed text-slate-500"></p>`;
      const [t, v, d] = card.querySelectorAll('p');
      t.textContent = perk.title; v.textContent = perk.value; d.textContent = perk.detail;
      return card;
    }));
    perksLoaded = true;
  } catch {
    perkList.textContent = 'Ưu đãi đăng ký thi IELTS qua ZIM và quà thi thử.';
  }
}

function resetVoucherView() {
  voucherResult.classList.add('hidden');
  voucherError.classList.add('hidden');
  claimButton.disabled = false;
  claimButton.textContent = 'Nhận quà';
  claimed = false;
  for (const card of perkList.children) { card.classList.remove('ticket-in'); void card.offsetWidth; card.classList.add('ticket-in'); }
}

async function celebrate() {
  if (reduceMotion) return;
  const { runConfetti } = await import('./confetti.js');
  runConfetti({ duration: 1600, particles: 110 });
}

async function showCompletionModal(detail = {}) {
  previouslyFocused = document.activeElement;
  (await ensureChat().catch(() => null))?.close();
  await loadPerks();
  resetVoucherView();
  modal.dataset.courseId = detail.courseId || 'ielts-demo';
  modal.dataset.courseName = detail.courseName || 'khóa Luyện thi IELTS';
  courseNameLabel.textContent = modal.dataset.courseName;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
  modal.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => { claimButton.focus(); celebrate().catch(() => {}); });
  track('voucher_modal_viewed', { courseId: modal.dataset.courseId });
}

function requestCompletionModal(detail = {}) {
  track('course_completed', detail);
  if (chatBusy) { queuedCompletion = detail; return; }
  showCompletionModal(detail);
}

async function closeCompletionModal({ openExamChat = false } = {}) {
  modal.classList.add('hidden');
  modal.classList.remove('flex');
  modal.setAttribute('aria-hidden', 'true');
  document.body.style.overflow = '';
  previouslyFocused?.focus?.();
  const chat = await ensureChat().catch(() => null);
  if (!chat) return;
  if (openExamChat) chat.ask('Mình muốn đăng ký thi IELTS qua ZIM', 'intent:EXAM');
  else setTimeout(() => chat.notify(
    ['Chúc mừng bạn đã hoàn thành khóa học nha 🎉', 'Nếu cần hỗ trợ đăng ký thi IELTS qua ZIM, bạn cứ nhắn mình nhé.'],
    [{ label: 'Đăng ký thi IELTS', value: 'intent:EXAM' }, { label: 'Để sau', value: 'intent:LATER' }],
  ), 700);
}

async function claimVoucher() {
  if (claimed) { closeCompletionModal({ openExamChat: true }); return; }
  if (claimButton.disabled) return;
  claimButton.disabled = true;
  claimButton.textContent = 'Đang tạo mã…';
  voucherError.classList.add('hidden');
  try {
    const response = await fetch('/api/vouchers/claim', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, courseId: modal.dataset.courseId, courseName: modal.dataset.courseName }),
    });
    if (!response.ok) throw new Error('claim failed');
    const { voucher } = await response.json();
    const expiry = new Intl.DateTimeFormat('vi-VN').format(new Date(voucher.expiresAt));
    const amount = voucher.amount ? ` · Giá trị ${new Intl.NumberFormat('vi-VN').format(voucher.amount)}đ` : '';
    voucherCode.textContent = voucher.code;
    voucherMeta.textContent = `Hạn dùng đến ${expiry}${amount}. ${voucher.idempotent ? 'Đây là mã bạn đã nhận trước đó.' : 'Đưa mã này cho tư vấn viên khi đăng ký thi.'} Mã dùng trong bản demo bài tập.`;
    voucherResult.classList.remove('hidden');
    claimed = true;
    claimButton.disabled = false;
    claimButton.textContent = 'Đăng ký thi qua ZIM';
    track('voucher_claimed', { voucherId: voucher.id, courseId: voucher.courseId, idempotent: voucher.idempotent });
  } catch {
    claimButton.disabled = false;
    claimButton.textContent = 'Thử lại';
    voucherError.textContent = 'Chưa tạo được mã lúc này, bạn thử lại giúp mình nha. Tiến độ khóa học vẫn được giữ nguyên.';
    voucherError.classList.remove('hidden');
  }
}

document.getElementById('copy-voucher')?.addEventListener('click', async () => {
  try { await navigator.clipboard.writeText(voucherCode.textContent); toast('Đã sao chép mã'); }
  catch { toast('Chưa sao chép được, bạn chọn và copy thủ công nha'); }
});
claimButton?.addEventListener('click', claimVoucher);
closeButton?.addEventListener('click', () => closeCompletionModal());
deferButton?.addEventListener('click', () => closeCompletionModal());
modal?.addEventListener('click', (event) => { if (event.target === modal) closeCompletionModal(); });
document.addEventListener('keydown', (event) => {
  if (modal.getAttribute('aria-hidden') !== 'false') return;
  if (event.key === 'Escape') { closeCompletionModal(); return; }
  if (event.key === 'Tab') { // giữ focus trong modal
    const items = [...modal.querySelectorAll('button:not([disabled]), [href]')].filter((n) => n.offsetParent !== null);
    if (!items.length) return;
    const first = items[0]; const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});

document.getElementById('simulate-completion')?.addEventListener('click', () => {
  const bar = document.getElementById('progress-bar');
  const label = document.getElementById('progress-label');
  if (bar) bar.style.width = '100%';
  if (label) label.textContent = '100%';
  setTimeout(() => requestCompletionModal({ courseId: 'ielts-demo', courseName: 'khóa Luyện thi IELTS' }), reduceMotion ? 0 : 750);
});

window.ZIMCompletionReward = { open: requestCompletionModal };

loadChatWhenIdle();
track('page_viewed', { path: location.pathname });
